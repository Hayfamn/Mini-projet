package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import modele.Medicament;
import modele.Medicament;

public class MedicamentDAO implements InterfaceDAO<Medicament>{

	@Override
	public void insert(Medicament e) throws SQLException {
		Connection cx=SingletonConnection.getInstance();
		String s="insert into medicament values(?,?,?,?,?);";
		PreparedStatement ps=cx.prepareStatement(s);
		ps.setInt(1,e.getIdMed());
		ps.setString(2,e.getNomMed());
		ps.setDouble(3,e.getPrix());
		ps.setInt(4,e.getStock());
		ps.setString(5,e.getDescriptionMed());		
		ps.executeUpdate();
		ps.close();
		
	}

	@Override
	public void delete(Medicament e) throws SQLException {
		Connection cx = SingletonConnection.getInstance();    
	     String s = "delete from medicament where idMed = ?;";
	     PreparedStatement p=cx.prepareStatement(s);
	     p.setInt(1, e.getIdMed());
	     p.executeUpdate();
	     p.close();
		
	}

	@Override
	public void update(Medicament e) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Medicament getById(int id) throws SQLException {
		Medicament med=null;
		Connection cx=SingletonConnection.getInstance();
		PreparedStatement ps=cx.prepareStatement("Select * from medicament where idMed=?;");
		ps.setInt(1, id);
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			med=new Medicament();
			med.setIdMed(rs.getInt("idMed"));
			med.setNomMed(rs.getString("nomMed"));
			med.setPrix(rs.getInt("prix"));
			med.setStock(rs.getInt("stock"));
			med.setDescriptionMed(rs.getString("descriptionMed"));
			
		}
		ps.close();
		return med;
	}

	@Override
	public List<Medicament> getByName(String nom) throws SQLException {
		List<Medicament> medicaments=new ArrayList<>();
		Connection cx=SingletonConnection.getInstance();
		PreparedStatement ps=cx.prepareStatement("Select * from medicament where nomMed=?;");
		ps.setString(1, nom);
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			Medicament med=new Medicament();
			med.setIdMed(rs.getInt("idMed"));
			med.setNomMed(rs.getString("nomMed"));
			med.setPrix(rs.getInt("prix"));
			med.setStock(rs.getInt("stock"));
			med.setDescriptionMed(rs.getString("descriptionMed"));
			medicaments.add(med);
		}
		ps.close();
		return medicaments;
	}

	@Override
	public List<Medicament> getAll() throws SQLException {
		List<Medicament> medicaments=new ArrayList<>();
		Connection cx=SingletonConnection.getInstance();
		PreparedStatement ps=cx.prepareStatement("Select * from medicament;");
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			Medicament med=new Medicament();
			med.setIdMed(rs.getInt("idMed"));
			med.setNomMed(rs.getString("nomMed"));
			med.setPrix(rs.getDouble("prix"));
			med.setStock(rs.getInt("stock"));
			med.setDescriptionMed(rs.getString("descriptionMed"));
			medicaments.add(med);
		}
		ps.close();
		return medicaments;
	}

}
