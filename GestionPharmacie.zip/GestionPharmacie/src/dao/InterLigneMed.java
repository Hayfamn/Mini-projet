package dao;

import java.sql.SQLException;
import java.util.List;

public interface InterLigneMed <E>{
	void insert(E e)throws SQLException;
	void delete(E e)throws SQLException;
	void update(E e)throws SQLException;
	E getById(int id1,int id2)throws SQLException;
	List<E> getAll()throws SQLException;
}
