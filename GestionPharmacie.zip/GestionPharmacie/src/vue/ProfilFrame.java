package vue;

import javax.swing.*;
import java.awt.*;
import modele.Utilisateur;

public class ProfilFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    public ProfilFrame(Utilisateur utilisateur) {
        setTitle("Profil utilisateur");
        setSize(300, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(3, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panel.add(new JLabel("Nom d'utilisateur : " + utilisateur.getNomUtilisateur()));
        panel.add(new JLabel("Mot de passe : " + utilisateur.getMotDePasse()));
        panel.add(new JLabel("Type : " + utilisateur.getType()));

        add(panel);
    }
}
