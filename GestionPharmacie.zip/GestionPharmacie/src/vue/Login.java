package vue;

import javax.swing.*;
import java.awt.*;
import dao.UtilisateurDAO;
import modele.Utilisateur;

public class Login extends JFrame {
    private static final long serialVersionUID = 1L;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    public Login() {
        setTitle("Connexion - Gestion Pharmacie");
        setSize(300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }
    private void initComponents() {
        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panel.add(new JLabel("Nom d'utilisateur:"));
        usernameField = new JTextField();
        panel.add(usernameField);

        panel.add(new JLabel("Mot de passe:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);

        loginButton = new JButton("Se connecter");
        panel.add(new JLabel());
        panel.add(loginButton);

        loginButton.addActionListener(e -> login());

        add(panel);
    }

    private void login() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();
        Utilisateur user = UtilisateurDAO.authentifier(username, password);
        if (user != null) {
            JOptionPane.showMessageDialog(this, "Bienvenue " + user.getNomUtilisateur());
            String type = user.getType().trim().toLowerCase(); 
            dispose(); 
            switch (type) {
                case "admin":
                    new AdminDashboard(user).setVisible(true);
                    break;
                case "pharmacien":
                    new PharmacienDashboard(user).setVisible(true);
                    break;
                default:
                    JOptionPane.showMessageDialog(this, "Type d'utilisateur inconnu : " + type, "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Identifiants invalides", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Login().setVisible(true));
    }
}
