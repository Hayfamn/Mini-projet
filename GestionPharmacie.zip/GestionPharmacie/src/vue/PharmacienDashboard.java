package vue;

import javax.swing.*;
import java.awt.*;
import modele.Utilisateur;

public class PharmacienDashboard extends JFrame {
    private static final long serialVersionUID = 1L;
    private Utilisateur pharmacien;

    public PharmacienDashboard(Utilisateur pharmacien) {
        this.pharmacien = pharmacien;
        setTitle("Tableau de bord - Pharmacien");
        setSize(500, 450);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new GridLayout(7, 1, 10, 10));

        JButton btnVoirPatient = new JButton("Patients");
        JButton btnVoirMedicaments = new JButton("Médicaments");
        JButton btnGérerOrdonnance = new JButton("Gérer une ordonnance");
        JButton btnRechercherOrdonnance = new JButton("Rechercher une ordonnance");
        JButton btnProfil = new JButton("Profil");
        JButton btnDeconnexion = new JButton("Déconnexion");

        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.add(btnVoirPatient);
        panel.add(btnVoirMedicaments);
        panel.add(btnGérerOrdonnance);
        panel.add(btnRechercherOrdonnance);
        panel.add(btnProfil);
        panel.add(btnDeconnexion);

        add(panel, BorderLayout.CENTER);

        btnProfil.addActionListener(e -> new ProfilFrame(pharmacien).setVisible(true));
        btnDeconnexion.addActionListener(e -> {
            dispose();
            new Login().setVisible(true);
        });
    }
}
