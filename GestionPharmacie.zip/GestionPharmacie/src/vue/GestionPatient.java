package vue;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;
import dao.PatientDAO;
import modele.Patient;

public class GestionPatient extends JFrame {
    private static final long serialVersionUID = 1L;

    private JTextField txtNom;
    private JTextField txtCredit;
    private DefaultListModel<String> patientListModel;
    private JList<String> patientList;
    private List<Patient> patients;
    private int selectedIndex = -1;

    public GestionPatient() {
        setTitle("Gestion des patients");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        initComponents();
        loadPatientsFromDB();
    }

    private void initComponents() {
        JPanel formPanel = new JPanel(new GridLayout(2, 2));
        formPanel.add(new JLabel("Nom :"));
        txtNom = new JTextField();
        formPanel.add(txtNom);
        formPanel.add(new JLabel("Crédit :"));
        txtCredit = new JTextField();
        formPanel.add(txtCredit);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton btnAjouter = new JButton("Ajouter");
        JButton btnModifier = new JButton("Modifier");
        JButton btnSupprimer = new JButton("Supprimer");
        JButton btnFermer = new JButton("Fermer");

        buttonPanel.add(btnAjouter);
        buttonPanel.add(btnModifier);
        buttonPanel.add(btnSupprimer);
        buttonPanel.add(btnFermer);

        patientListModel = new DefaultListModel<>();
        patientList = new JList<>(patientListModel);
        JScrollPane scrollPane = new JScrollPane(patientList);

        patientList.addListSelectionListener(e -> {
            selectedIndex = patientList.getSelectedIndex();
            if (selectedIndex != -1 && selectedIndex < patients.size()) {
                Patient p = patients.get(selectedIndex);
                txtNom.setText(p.getNomPat());
                txtCredit.setText(String.valueOf(p.getCredit()));
            }
        });

        btnAjouter.addActionListener(e -> {
            String nom = txtNom.getText().trim();
            String creditStr = txtCredit.getText().trim();
            if (!nom.isEmpty() && !creditStr.isEmpty()) {
                try {
                    double credit = Double.parseDouble(creditStr);
                    Patient p = new Patient(nom, credit);
                    new PatientDAO().insert(p);
                    loadPatientsFromDB();
                    txtNom.setText("");
                    txtCredit.setText("");
                } catch (NumberFormatException | SQLException ex) {
                    JOptionPane.showMessageDialog(this, "Erreur : " + ex.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.");
            }
        });

        btnModifier.addActionListener(e -> {
            if (selectedIndex != -1 && selectedIndex < patients.size()) {
                String nom = txtNom.getText().trim();
                String creditStr = txtCredit.getText().trim();
                if (!nom.isEmpty() && !creditStr.isEmpty()) {
                    try {
                        double credit = Double.parseDouble(creditStr);
                        Patient p = patients.get(selectedIndex);
                        p.setNomPat(nom);
                        p.setCredit(credit);
                        new PatientDAO().update(p);
                        loadPatientsFromDB();
                        txtNom.setText("");
                        txtCredit.setText("");
                        patientList.clearSelection();
                    } catch (NumberFormatException | SQLException ex) {
                        JOptionPane.showMessageDialog(this, "Erreur : " + ex.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });

        btnSupprimer.addActionListener(e -> {
            if (selectedIndex != -1 && selectedIndex < patients.size()) {
                try {
                    Patient p = patients.get(selectedIndex);
                    new PatientDAO().delete(p);
                    loadPatientsFromDB();
                    txtNom.setText("");
                    txtCredit.setText("");
                    patientList.clearSelection();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(this, "Erreur : " + ex.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        btnFermer.addActionListener(e -> dispose());

        setLayout(new BorderLayout());
        add(formPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void loadPatientsFromDB() {
        try {
            patients = new PatientDAO().getAll();
            patientListModel.clear();
            for (Patient p : patients) {
                patientListModel.addElement(p.getNomPat() + " (Crédit: " + p.getCredit() + ")");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erreur lors du chargement des patients : " + e.getMessage());
        }
    }
}
