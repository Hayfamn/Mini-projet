package vue;

import javax.swing.*;
import java.awt.*;
import modele.Utilisateur;

public class AdminDashboard extends JFrame {
    private static final long serialVersionUID = 1L;
    private Utilisateur admin;

    public AdminDashboard(Utilisateur admin) {
        this.admin = admin;
        setTitle("Tableau de bord - Administrateur");
        setSize(400, 350);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new GridLayout(5, 1, 10, 10));
        JButton btnProfil = new JButton("Profil");
        JButton btnGererPatients = new JButton("Gérer les patients");
        JButton btnGererMedicaments = new JButton("Gérer les médicaments");
        JButton btnGererStock = new JButton("Gérer le stock d’un médicament");

        JButton btnDeconnexion = new JButton("Déconnexion");

        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.add(btnGererPatients);
        panel.add(btnGererMedicaments);
        panel.add(btnGererStock);
        panel.add(btnProfil);
        panel.add(btnDeconnexion);

        add(panel, BorderLayout.CENTER);

        btnGererPatients.addActionListener(e -> new GestionPatient().setVisible(true));
        btnProfil.addActionListener(e -> new ProfilFrame(admin).setVisible(true));
        btnDeconnexion.addActionListener(e -> {
            dispose();
            new Login().setVisible(true);
        });
    }
}
