package presentation;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import dao.SingletonConnection;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.BorderLayout;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.MatteBorder;

public class MenuPrincipal extends JFrame{

	private JFrame frmLogin;
	private JTextField textField;
	private JPasswordField passwordField;
    
    JComboBox<String> comboBox;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuPrincipal window = new MenuPrincipal();
					window.frmLogin.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MenuPrincipal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmLogin = new JFrame();
		frmLogin.setResizable(false);
		frmLogin.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\nermine\\OneDrive\\Bureau\\src_img\\Logo-Pharmacie.jpg"));
		frmLogin.setTitle("LOGIN");
		frmLogin.setBounds(100, 100, 1121, 695);
		frmLogin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		JLabel lblNewLabel = new JLabel("SYSTEME GESTION DE PHARMACIE");
		lblNewLabel.setForeground(new Color(34, 139, 34));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		JLabel lblNewLabel_1 = new JLabel("NOM D'UTILISATEUR : ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		
		JLabel lblNewLabel_1_1 = new JLabel("MOT DE PASSE : ");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		
		textField = new JTextField();
		textField.setColumns(20);
		
		passwordField = new JPasswordField();
		JCheckBox showPassCheckBox = new JCheckBox("Afficher le mot de passe");
		showPassCheckBox.setFont(new Font("Tahoma", Font.BOLD, 13));
		showPassCheckBox.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent e) {
		        JCheckBox checkBox = (JCheckBox) e.getSource();
		        if (checkBox.isSelected()) {
		            passwordField.setEchoChar((char) 0); // Caractère non masqué
		        } else {
		            passwordField.setEchoChar('•'); // Caractère masqué par défaut
		        }
		    }
		});
		
		JButton btnNewButton = new JButton("Valider");
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String login=textField.getText();
				char[] pass=passwordField.getPassword();
				String password=new String(pass);
				
				
				
				Connection conn=SingletonConnection.getInstance();
				
				if(login.isEmpty() || password.isEmpty()){
					JOptionPane.showMessageDialog(null, "Veuillez remplir tous les champs!");
		            
				}else {
				
				
				try {
					if(String.valueOf(comboBox.getSelectedItem())=="Administrateur") {
					    PreparedStatement ps;
					    ps=conn.prepareStatement("select log, passwd from administrateur where log=? and passwd=?");
					    ps.setString(1, login);
					    ps.setString(2, password);
					    ResultSet rs=ps.executeQuery();
					    if(rs.next()) {
					    	//dispose();
					    	presentation.AdministrateurPres ad=new presentation.AdministrateurPres();
					    	
					    }else {
			                JOptionPane.showMessageDialog(null, "Nom d'utilisateur ou mot de passe incorrect!");
			            }
					    ps.close();
					}
					else if(String.valueOf(comboBox.getSelectedItem())=="Pharmacien") {
						PreparedStatement ps;
						ps=conn.prepareStatement("select login, passwd from pharmacien where login=? and passwd=?");
						ps.setString(1, login);
						ps.setString(2, password);
						ResultSet rs=ps.executeQuery();
						if(rs.next()) {
							//dispose();
							presentation.PharmacienPres ph=new presentation.PharmacienPres();
						}else {
			                JOptionPane.showMessageDialog(null, "Nom d'utilisateur ou mot de passe incorrect!");
			            }
						ps.close();
					}
				
					
					
				}catch(SQLException ex) {
					ex.printStackTrace();
				}
				
			}}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		
		JLabel lblNewLabel_3 = new JLabel("Type :");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		
		comboBox = new JComboBox<String>();
		comboBox.setFont(new Font("Tahoma", Font.BOLD, 14));
		comboBox.setModel(new DefaultComboBoxModel<String>(new String[] {"Administrateur", "Pharmacien"}));

		
		
		JPanel panel_2 = new JPanel();
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(644, 0, 270, 499);
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0)));
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\nermine\\eclipse-workspace\\SystemeGestionPharmacie\\pharmacien.jpg"));
		GroupLayout groupLayout = new GroupLayout(frmLogin.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(10)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(panel, GroupLayout.DEFAULT_SIZE, 1080, Short.MAX_VALUE)
							.addGap(7))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 508, Short.MAX_VALUE)
							.addGap(5)
							.addComponent(panel_2, GroupLayout.DEFAULT_SIZE, 574, Short.MAX_VALUE)
							.addPreferredGap(ComponentPlacement.RELATED)))
					.addGap(10))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(26)
					.addComponent(panel, GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
					.addGap(10)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 499, Short.MAX_VALUE)
							.addGap(10))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(panel_2, GroupLayout.DEFAULT_SIZE, 499, Short.MAX_VALUE)
							.addContainerGap())))
		);
		panel_2.setLayout(new BorderLayout(0, 0));
		panel_2.add(lblNewLabel_2, BorderLayout.CENTER);
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(27)
					.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, 171, Short.MAX_VALUE)
					.addGap(43)
					.addComponent(textField, GroupLayout.DEFAULT_SIZE, 244, Short.MAX_VALUE)
					.addGap(21))
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(27)
					.addComponent(lblNewLabel_1_1, GroupLayout.DEFAULT_SIZE, 171, Short.MAX_VALUE)
					.addGap(43)
					.addComponent(passwordField, GroupLayout.DEFAULT_SIZE, 244, Short.MAX_VALUE)
					.addGap(21))
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(91)
					.addComponent(showPassCheckBox, GroupLayout.DEFAULT_SIZE, 244, Short.MAX_VALUE)
					.addGap(171))
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(27)
					.addComponent(lblNewLabel_3, GroupLayout.DEFAULT_SIZE, 171, Short.MAX_VALUE)
					.addGap(43)
					.addComponent(comboBox, 0, 244, Short.MAX_VALUE)
					.addGap(21))
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(194)
					.addComponent(btnNewButton, GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE)
					.addGap(171))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(116)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(3)
							.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, 20, Short.MAX_VALUE)
							.addGap(9))
						.addComponent(textField, GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE))
					.addGap(61)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(3)
							.addComponent(lblNewLabel_1_1, GroupLayout.DEFAULT_SIZE, 20, Short.MAX_VALUE)
							.addGap(9))
						.addComponent(passwordField, GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE))
					.addGap(25)
					.addComponent(showPassCheckBox, GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
					.addGap(27)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(4)
							.addComponent(lblNewLabel_3, GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
							.addGap(3))
						.addComponent(comboBox, GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE))
					.addGap(44)
					.addComponent(btnNewButton, GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
					.addGap(29))
		);
		panel_1.setLayout(gl_panel_1);
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 1080, Short.MAX_VALUE)
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
		);
		panel.setLayout(gl_panel);
		frmLogin.getContentPane().setLayout(groupLayout);
		frmLogin.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frmLogin.addWindowListener(new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent e) {
		        frmLogin.dispose();
		    }
		});
		
		
	}
	
}
