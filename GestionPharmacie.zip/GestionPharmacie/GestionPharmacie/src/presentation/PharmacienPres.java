package presentation;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

import dao.PharmacienDAO;
import metier.Client;
import metier.Medicament;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;

public class PharmacienPres extends JFrame{

	private JFrame frmPharmacien;
	public static JTextField textField;
	private JPanel panel_1;
	private JTextField textField_Code;
	private JTextField textField_CodeType;
	private JTextField textField_Libelle;
	private JTextField textField_Quantite;
	public static JTextField textField_1;
	private MenuPrincipal menu;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PharmacienPres window = new PharmacienPres();
					window.frmPharmacien.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PharmacienPres() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPharmacien = new JFrame();
		frmPharmacien.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\nermine\\OneDrive\\Bureau\\src_img\\Logo-Pharmacie.jpg"));
		frmPharmacien.setTitle("PHARMACIEN");
		frmPharmacien.setBounds(100, 100, 1121, 695);
		frmPharmacien.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		JLabel lblNewLabel = new JLabel("SYSTEME GESTION DE PHARMACIE");
		lblNewLabel.setForeground(new Color(34, 139, 34));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 1080, Short.MAX_VALUE)
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
		);
		panel.setLayout(gl_panel);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		JButton btnNewButton = new JButton("Consulter les clients");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		
		JButton btnNewButton_1 = new JButton("Consulter les médicaments");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		
		JButton btnNewButton_2 = new JButton("Gérer les ordonnances");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\nermine\\eclipse-workspace\\SystemeGestionPharmacie\\bienvenue.gif"));
		panel_3.add(lblNewLabel_2);
		
	    panel_1 = new JPanel();
	    panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setColumns(10);
		
		
		
		
		JButton btnNewButton_3 = new JButton("Rechercher un medicament");
		btnNewButton_3.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e){
				    Recherche rech=new Recherche();
				    //rech.setVisible(true);
				    
				    
			 }});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		
		textField_1 = new JTextField();
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setColumns(10);
		
		JButton btnNewButton_3_1 = new JButton("Rechercher une ordonnance");
		btnNewButton_3_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		GroupLayout groupLayout = new GroupLayout(frmPharmacien.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(10)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(panel, GroupLayout.DEFAULT_SIZE, 1087, Short.MAX_VALUE)
							.addContainerGap())
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(panel_3, GroupLayout.DEFAULT_SIZE, 1087, Short.MAX_VALUE)
							.addContainerGap())
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(panel_2, GroupLayout.DEFAULT_SIZE, 458, Short.MAX_VALUE)
							.addGap(10)
							.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 619, Short.MAX_VALUE)
							.addGap(10))))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(26)
					.addComponent(panel, GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
					.addGap(10)
					.addComponent(panel_3, GroupLayout.PREFERRED_SIZE, 200, Short.MAX_VALUE)
					.addGap(10)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(panel_2, GroupLayout.DEFAULT_SIZE, 278, Short.MAX_VALUE)
						.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 278, Short.MAX_VALUE))
					.addGap(21))
		);
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(37)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addComponent(textField, GroupLayout.DEFAULT_SIZE, 266, Short.MAX_VALUE)
							.addGap(36)
							.addComponent(btnNewButton_3, GroupLayout.DEFAULT_SIZE, 252, Short.MAX_VALUE))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addComponent(textField_1, GroupLayout.DEFAULT_SIZE, 266, Short.MAX_VALUE)
							.addGap(36)
							.addComponent(btnNewButton_3_1, GroupLayout.DEFAULT_SIZE, 252, Short.MAX_VALUE)))
					.addGap(26))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(38)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addComponent(textField, GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addComponent(btnNewButton_3, GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
							.addGap(6)))
					.addGap(66)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addComponent(textField_1, GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addComponent(btnNewButton_3_1, GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
							.addGap(6)))
					.addGap(84))
		);
		panel_1.setLayout(gl_panel_1);
		GroupLayout gl_panel_2 = new GroupLayout(panel_2);
		gl_panel_2.setHorizontalGroup(
			gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup()
					.addGap(66)
					.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
						.addComponent(btnNewButton, GroupLayout.DEFAULT_SIZE, 264, Short.MAX_VALUE)
						.addComponent(btnNewButton_1, GroupLayout.DEFAULT_SIZE, 264, Short.MAX_VALUE)
						.addComponent(btnNewButton_2, GroupLayout.DEFAULT_SIZE, 264, Short.MAX_VALUE))
					.addGap(126))
		);
		gl_panel_2.setVerticalGroup(
			gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup()
					.addGap(31)
					.addComponent(btnNewButton, GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
					.addGap(53)
					.addComponent(btnNewButton_1, GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
					.addGap(51)
					.addComponent(btnNewButton_2, GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
					.addGap(45))
		);
		panel_2.setLayout(gl_panel_2);
		frmPharmacien.getContentPane().setLayout(groupLayout);
		
        btnNewButton_3_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		RecherchOrd rechOrd = new RecherchOrd();
        	}
        });
		
		frmPharmacien.setVisible(true);
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				JFrame frmConsult = new JFrame();
				frmConsult.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\nermine\\OneDrive\\Bureau\\src_img\\Logo-Pharmacie.jpg"));
				frmConsult.setTitle("CONSULTATION DES CLIENTS");
				frmConsult.setBounds(100, 100, 1121, 695);
				frmConsult.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

				// Création du panel principal
				JPanel panel = new JPanel();
				frmConsult.getContentPane().add(panel, BorderLayout.CENTER);

				// Création et ajout du JTable dans un JScrollPane
				ClientModel clientModel = new ClientModel();
				JTable jTable = new JTable(clientModel);

				jTable.setSize(Toolkit.getDefaultToolkit().getScreenSize());

				JScrollPane jScrollPane = new JScrollPane(jTable);
				jTable.setFillsViewportHeight(true);

				// Chargement des données de la table des clients depuis la base de données
				PharmacienDAO phDAO = new PharmacienDAO();
				List<Client> clients = phDAO.consulterClient();
				clientModel.loadData(clients);

				// Création du GroupLayout pour le panel principal
				GroupLayout gl_panel = new GroupLayout(panel);
				panel.setLayout(gl_panel);

				// Configuration du GroupLayout
				gl_panel.setHorizontalGroup(
				    gl_panel.createParallelGroup(Alignment.LEADING)
				        .addComponent(jScrollPane, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				);
				gl_panel.setVerticalGroup(
				    gl_panel.createParallelGroup(Alignment.LEADING)
				        .addComponent(jScrollPane, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				);

				frmConsult.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
				frmConsult.addWindowListener(new WindowAdapter() {
				    @Override
				    public void windowClosing(WindowEvent e) {
				        frmConsult.dispose();
				    }
				});
				
				frmConsult.setVisible(true);
				

			}
		});
		
		
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				JFrame frmConsult_1 = new JFrame();
				frmConsult_1.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\nermine\\OneDrive\\Bureau\\src_img\\Logo-Pharmacie.jpg"));
				frmConsult_1.setTitle("CONSULTATION DES MEDICAMENTS");
				frmConsult_1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frmConsult_1.setBounds(100, 100, 1183, 628);

				// Création d'un panel pour ajouter le JTable
				JPanel panel_1 = new JPanel();
				GroupLayout gl_panel_1 = new GroupLayout(panel_1);
				panel_1.setLayout(gl_panel_1);
				frmConsult_1.getContentPane().add(panel_1, BorderLayout.CENTER);

				// Création et ajout du JTable dans un JScrollPane
				MedicamentModel medicamentModel = new MedicamentModel();
				JTable jTable_1 = new JTable(medicamentModel);
				jTable_1.setFillsViewportHeight(true);

				JScrollPane jScrollPane_1 = new JScrollPane(jTable_1);
				gl_panel_1.setHorizontalGroup(gl_panel_1.createParallelGroup(GroupLayout.Alignment.LEADING)
				    .addComponent(jScrollPane_1, GroupLayout.DEFAULT_SIZE, frmConsult_1.getWidth(), Short.MAX_VALUE)
				);
				gl_panel_1.setVerticalGroup(gl_panel_1.createParallelGroup(GroupLayout.Alignment.LEADING)
				    .addComponent(jScrollPane_1, GroupLayout.DEFAULT_SIZE, frmConsult_1.getHeight(), Short.MAX_VALUE)
				);

				// Chargement des données de la table des clients depuis la base de données
				PharmacienDAO phDAO = new PharmacienDAO();
				List<Medicament> medicaments = phDAO.consulterMédicament();
				medicamentModel.loadData(medicaments);

                
				frmConsult_1.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
				
				frmConsult_1.addWindowListener(new WindowAdapter() {
				    @Override
				    public void windowClosing(WindowEvent e) {
				        frmConsult_1.dispose();
				    }
				    
				});

				
				frmConsult_1.setVisible(true);
				
			}
		});
		
		
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GestOrd gstOrd = new GestOrd();

			}
		});
		
		frmPharmacien.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frmPharmacien.addWindowListener(new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent e) {
		        frmPharmacien.dispose();
		    }
		});
		
	
	}
}
