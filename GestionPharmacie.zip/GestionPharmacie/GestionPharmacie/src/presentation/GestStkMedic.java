package presentation;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import dao.AdministrateurDAO;
import dao.PharmacienDAO;
import metier.Medicament;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.border.LineBorder;

public class GestStkMedic {

	private JFrame frame;
	private JTable table;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GestStkMedic window = new GestStkMedic();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GestStkMedic() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\nermine\\OneDrive\\Bureau\\src_img\\Logo-Pharmacie.jpg"));
		frame.setTitle("GESTION DE STOCK DES MEDICAMENTS");
		frame.setBounds(100, 100, 1550, 749);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		//frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		JLabel lblNewLabel = new JLabel("Valeur Stock ");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Augmenter le stock");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdministrateurDAO adDAO = new AdministrateurDAO();
				MedicamentModel medicamentModel = new MedicamentModel();
				PharmacienDAO phDAO = new PharmacienDAO();
				adDAO.ajoutStk(new PharmacienDAO().rechercherMedicament(String.valueOf(textField_1.getText())), Integer.valueOf(textField.getText()));
				
				// Charger toutes les données depuis la base de données
	             List<Medicament> medicaments = phDAO.consulterMédicament();
	             
	             // Charger les données dans le modèle de données de la JTable
	             medicamentModel.loadData(medicaments);
	             
	             // Rafraîchir la vue de la table
	             table.setModel(medicamentModel);
				
			}
		});
		
		
		JButton btnNewButton_1 = new JButton("Diminuer le stock");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		JLabel lblNewLabel_1 = new JLabel("codeMedicament");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setBackground(new Color(240, 240, 240));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setColumns(10);
		
		
		
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdministrateurDAO adDAO = new AdministrateurDAO();
				MedicamentModel medicamentModel = new MedicamentModel();
				PharmacienDAO phDAO = new PharmacienDAO();
				adDAO.supprimStk(new PharmacienDAO().rechercherMedicament(String.valueOf(textField_1.getText())), Integer.valueOf(textField.getText()));
				
				// Charger toutes les données depuis la base de données
	             List<Medicament> medicaments = phDAO.consulterMédicament();
	             
	             // Charger les données dans le modèle de données de la JTable
	             medicamentModel.loadData(medicaments);
	             
	             // Rafraîchir la vue de la table
	             table.setModel(medicamentModel);
				
			}
		});
		
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		MedicamentModel medicamentModel = new MedicamentModel();
		
		table = new JTable(medicamentModel);
		table.setFont(new Font("Tahoma", Font.PLAIN, 13));

		

		JScrollPane scrollPane = new JScrollPane(table);
		table.setFillsViewportHeight(true);
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(panel, GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
					.addGap(10)
					.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 1126, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(panel, GroupLayout.DEFAULT_SIZE, 781, Short.MAX_VALUE)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 702, Short.MAX_VALUE)
					.addContainerGap())
		);
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 1104, Short.MAX_VALUE)
					.addContainerGap())
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 680, Short.MAX_VALUE)
					.addContainerGap())
		);
		panel_1.setLayout(gl_panel_1);
		
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(36)
					.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, 318, Short.MAX_VALUE)
					.addGap(46))
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(36)
					.addComponent(textField_1, GroupLayout.DEFAULT_SIZE, 318, Short.MAX_VALUE)
					.addGap(46))
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(36)
					.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 318, Short.MAX_VALUE)
					.addGap(46))
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(36)
					.addComponent(textField, GroupLayout.DEFAULT_SIZE, 318, Short.MAX_VALUE)
					.addGap(46))
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(24)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(btnNewButton, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 346, Short.MAX_VALUE)
						.addComponent(btnNewButton_1, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 346, Short.MAX_VALUE))
					.addGap(30))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(43)
					.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, 51, Short.MAX_VALUE)
					.addGap(21)
					.addComponent(textField_1, GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE)
					.addGap(28)
					.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 55, Short.MAX_VALUE)
					.addGap(26)
					.addComponent(textField, GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE)
					.addGap(129)
					.addComponent(btnNewButton, GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE)
					.addGap(88)
					.addComponent(btnNewButton_1, GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE)
					.addGap(108))
		);
		panel.setLayout(gl_panel);
		frame.getContentPane().setLayout(groupLayout);
		

		// Charger les données de la table des clients depuis la base de données
		try (PharmacienDAO phDAO = new PharmacienDAO()) {
		    List<Medicament> medicaments = phDAO.consulterMédicament();
		    medicamentModel.loadData(medicaments);
		}catch(Exception ex) {
		    ex.printStackTrace();
		}
		
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.addWindowListener(new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent e) {
		        frame.dispose();
		    }
		});
		
		frame.setVisible(true);
		
	}
	
	
	
	public boolean valeursExistantes(JTable table, JTextField[] textFields) {
	    MedicamentModel model = (MedicamentModel) table.getModel();
	    
	    for (int i = 0; i < model.getRowCount(); i++) {
	        boolean valeursIdentiques = true;
	        for (int j = 0; j < textFields.length; j++) {
	            Object valeurCellule = model.getValueAt(i, j);
	            String valeurTextField = textFields[j].getText();
	            if (!valeurCellule.equals(valeurTextField)) {
	                valeursIdentiques = false;
	                break;
	            }
	        }
	        if (valeursIdentiques) {
	            return true;
	        }
	    }
	    return false;
	}
}
