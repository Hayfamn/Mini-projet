package presentation;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import dao.MedicamentOrdonnanceDAO;
import metier.MedicamentOrdonnance;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class MedicOrd {

//	private JFrame frame;
//	private JTable table;
//
//	/**
//	 * Launch the application.
//	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					MedicOrd window = new MedicOrd();
//					window.frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}
//
//	/**
//	 * Create the application.
//	 */
//	public MedicOrd() {
//		initialize();
//	}
//
//	/**
//	 * Initialize the contents of the frame.
//	 */
//	private void initialize() {
//		frame = new JFrame();
//		frame.setBounds(100, 100, 505, 470);
//		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		DefaultTableModel tableModel = new DefaultTableModel();
//        tableModel.addColumn("Code Médicament");
//        tableModel.addColumn("Nom Médicament");
//        tableModel.addColumn("Quantité");
//        tableModel.addColumn("Dosage");
//
//        table = new JTable(tableModel);
//        JScrollPane scrollPane = new JScrollPane(table);
//
//        frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
//
//        JButton buttonAfficher = new JButton("Afficher Médicaments");
//        buttonAfficher.addActionListener(e -> {
//            String codeOrdonnance = JOptionPane.showInputDialog(null, "Entrez le code de l'ordonnance :");
//            if (codeOrdonnance != null && !codeOrdonnance.isEmpty()) {
//                MedicamentOrdonnanceDAO medordDAO = new MedicamentOrdonnanceDAO();
//
//                // Appeler la méthode getMedicamentByOrdonnance pour récupérer les données
//                List<MedicamentOrdonnance> medicaments = medordDAO.getMedicamentByOrdonnance(codeOrdonnance);
//
//                // Remplir le modèle de données de la table avec les données récupérées
//                for (MedicamentOrdonnance medicament : medicaments) {
//                    String codeMedicament = medicament.getCodeMedicament();
//                    String nomMedicament = medicament.getNomMedicament();
//                    int quantite = medicament.getQuantite();
//                    String dosage = medicament.getDosage();
//
//                    tableModel.addRow(new Object[]{codeMedicament, nomMedicament, quantite, dosage});
//                }
//            }
//        });
//
//        JPanel panel = new JPanel();
//        panel.add(buttonAfficher);
//        frame.getContentPane().add(panel, BorderLayout.SOUTH);
//
//        frame.pack();
//        frame.setVisible(true);
//    }
//	}
	
	
	private JFrame frame;
	private JTable table;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MedicOrd window = new MedicOrd();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public MedicOrd() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\nermine\\eclipse-workspace\\GestionPharmacie\\Logo-Pharmacie.jpg"));
		frame.setBounds(100, 100, 1316, 550);
		frame.setTitle("MEDICAMENT D'UNE ORDONNANCE");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		DefaultTableModel tableModel = new DefaultTableModel();
		tableModel.addColumn("Code Médicament");
		tableModel.addColumn("Nom Médicament");
		tableModel.addColumn("Quantité");
		tableModel.addColumn("Dosage");
		frame.getContentPane().setLayout(null);

		table = new JTable(tableModel);
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(0, 0, 1302, 480);
		//table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.getColumnModel().getColumn(0).setPreferredWidth(100); // Colonne 0
		table.getColumnModel().getColumn(1).setPreferredWidth(150); // Colonne 1
		table.getColumnModel().getColumn(2).setPreferredWidth(120); // Colonne 2
		table.getColumnModel().getColumn(3).setPreferredWidth(400);
		frame.getContentPane().add(scrollPane);

		JButton buttonAfficher = new JButton("Afficher Médicaments");
		buttonAfficher.setFont(new Font("Tahoma", Font.BOLD, 12));
		buttonAfficher.addActionListener(e -> {
			String codeOrdonnance = JOptionPane.showInputDialog(null, "Entrez le code de l'ordonnance :");
			if (codeOrdonnance != null && !codeOrdonnance.isEmpty()) {
				MedicamentOrdonnanceDAO medordDAO = new MedicamentOrdonnanceDAO();

				// Appeler la méthode getMedicamentByOrdonnance pour récupérer les données
				List<MedicamentOrdonnance> medicaments = medordDAO.getMedicamentByOrdonnance(codeOrdonnance);

				// Remplir le modèle de données de la table avec les données récupérées
				for (MedicamentOrdonnance medicament : medicaments) {
					String codeMedicament = medicament.getCodeMedicament();
					String nomMedicament = medicament.getNomMedicament();
					int quantite = medicament.getQuantite();
					String dosage = medicament.getDosage();

					tableModel.addRow(new Object[] { codeMedicament, nomMedicament, quantite, dosage });
					
					
				}
			}
		});

		JPanel panel = new JPanel();
		panel.setBounds(0, 480, 1302, 33);
		panel.add(buttonAfficher);
		frame.getContentPane().add(panel);
		
		
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.addWindowListener(new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent e) {
		        frame.dispose();
		    }
		});

		//frame.pack();
		frame.setVisible(true);
	}
}


