package presentation;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTable;
import dao.AdministrateurDAO;
import dao.PharmacienDAO;
import metier.Client;
import java.util.List;

import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JScrollPane;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.SwingConstants;

public class GestClient {

	private JFrame frame;
	private JTextField textField;
	private JTable table;
	private JScrollPane scrollPane;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GestClient window = new GestClient();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GestClient() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\nermine\\OneDrive\\Bureau\\src_img\\Logo-Pharmacie.jpg"));
		frame.setTitle("GESTION DES CLIENTS");
		frame.setBounds(100, 100, 1183, 628);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		JLabel lblNewLabel = new JLabel("idClient :");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("nomClient :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("prenomClient :");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField_2.setHorizontalAlignment(SwingConstants.CENTER);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("credit :");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField_3.setHorizontalAlignment(SwingConstants.CENTER);
		textField_3.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("codeOrdonnance :");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField_4.setHorizontalAlignment(SwingConstants.CENTER);
		textField_4.setColumns(10);
		
		JButton btnNewButton = new JButton("Ajouter Client");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		JButton btnNewButton_1 = new JButton("Modfier Client");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		JButton btnNewButton_2 = new JButton("Supprimer Client");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(5)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 59, Short.MAX_VALUE)
							.addGap(67)
							.addComponent(textField, GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE))
						.addGroup(gl_panel.createSequentialGroup()
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel_3, GroupLayout.DEFAULT_SIZE, 126, Short.MAX_VALUE)
								.addGroup(gl_panel.createSequentialGroup()
									.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addGap(51))
								.addComponent(lblNewLabel_2, GroupLayout.DEFAULT_SIZE, 126, Short.MAX_VALUE)
								.addGroup(gl_panel.createSequentialGroup()
									.addComponent(lblNewLabel_4, GroupLayout.DEFAULT_SIZE, 126, Short.MAX_VALUE)
									.addPreferredGap(ComponentPlacement.RELATED)))
							.addGap(0)
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(textField_1, GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
								.addComponent(textField_2, GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
								.addComponent(textField_3, GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
								.addComponent(textField_4, GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE))))
					.addContainerGap())
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(42)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(btnNewButton, GroupLayout.DEFAULT_SIZE, 143, Short.MAX_VALUE)
						.addComponent(btnNewButton_2, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
						.addComponent(btnNewButton_1, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE))
					.addGap(61))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(6)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(11)
							.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
						.addComponent(textField, GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE))
					.addGap(33)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(11)
							.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
						.addComponent(textField_1, GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE))
					.addGap(34)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(15)
							.addComponent(lblNewLabel_2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
						.addComponent(textField_2, GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE))
					.addGap(30)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(13)
							.addComponent(lblNewLabel_3, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
						.addComponent(textField_3, GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE))
					.addGap(37)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(13)
							.addComponent(lblNewLabel_4, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
						.addComponent(textField_4, GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE))
					.addGap(81)
					.addComponent(btnNewButton, GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
					.addGap(50)
					.addComponent(btnNewButton_1, GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
					.addGap(51)
					.addComponent(btnNewButton_2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGap(49))
		);
		panel.setLayout(gl_panel);
		
        JTextField[] textFields = {textField, textField_1, textField_2, textField_3, textField_4};

		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (existeLigne(table, textField.getText(), textField_1.getText(), textField_2.getText(), Float.valueOf(textField_3.getText()), textField_4.getText())) {
				    JOptionPane.showMessageDialog(null, "Valeurs déjà existentes !");
				} else {
				    // Ajouter le code pour gérer l'action
				    int idClient = Integer.valueOf(textField.getText());
				    String nomClient = textField_1.getText();
				    String prenomClient = textField_2.getText();
				    float credit = Float.valueOf(textField_3.getText());
				    String codeOrdonnance = textField_4.getText();

				    PharmacienDAO phDAO = new PharmacienDAO();
				    AdministrateurDAO admDAO = new AdministrateurDAO();
				    ClientModel clientModel = new ClientModel();
				    try {
				        // Appeler la fonction d'ajout dans la base de données
				        admDAO.ajoutClient(new Client(idClient, nomClient, prenomClient, codeOrdonnance, credit));

				        // Charger toutes les données depuis la base de données
				        List<Client> clients = phDAO.consulterClient();

				        // Charger les données dans le modèle de données de la JTable
				        clientModel.loadData(clients);

				        // Rafraîchir la vue de la table
				        table.setModel(clientModel);
				    } catch (Exception ex) {
				        ex.printStackTrace();
				    }
			}
			}
		});
		
		
		
		
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Ajouter un code pour gérer l'action
		    	 int idClient = Integer.valueOf(textField.getText());
		         String nomClient = textField_1.getText();
		         String prenomClient = textField_2.getText();
		         float credit = Float.valueOf(textField_3.getText());
		         String codeOrdonnance = textField_4.getText();
		         

		         

		         PharmacienDAO phDAO = new PharmacienDAO();
		         AdministrateurDAO admDAO = new AdministrateurDAO();
		         ClientModel clientModel = new ClientModel();
		         try {
		             // Appeler la fonction d'update dans la base de données
		            admDAO.modifClient(new Client(idClient, nomClient, prenomClient, codeOrdonnance, credit));
		             
		             // Charger toutes les données depuis la base de données
		             List<Client> clients = phDAO.consulterClient();
		             
		             
		             // Charger les données dans le modèle de données de la JTable
		             clientModel.loadData(clients);
		             
		             // Rafraîchir la vue de la table
		             table.setModel(clientModel);
		         } catch(Exception ex) {
		             ex.printStackTrace();
		         }
			}
		});
		
		
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Ajouter un code pour gérer l'action
		    	 int idClient = Integer.valueOf(textField.getText());
		         String nomClient = textField_1.getText();
		         String prenomClient = textField_2.getText();
		         float credit = Float.valueOf(textField_3.getText());
		         String codeOrdonnance = textField_4.getText();
		         

		         

		         PharmacienDAO phDAO = new PharmacienDAO();
		         AdministrateurDAO admDAO = new AdministrateurDAO();
		         ClientModel clientModel = new ClientModel();
		         try {
		             // Appeler la fonction de delete dans la base de données
		            admDAO.supprimClient(idClient);
		             
		             // Charger toutes les données depuis la base de données
		             List<Client> clients = phDAO.consulterClient();
		             
		             
		             // Charger les données dans le modèle de données de la JTable
		             clientModel.loadData(clients);
		             
		             // Rafraîchir la vue de la table
		             table.setModel(clientModel);
		         } catch(Exception ex) {
		             ex.printStackTrace();
		         }
			}
		});
		
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		ClientModel clientModel = new ClientModel();
		
		
		
		scrollPane = new JScrollPane(table);
		
		table = new JTable(clientModel);
		table.setFont(new Font("Tahoma", Font.PLAIN, 13));
		scrollPane.setViewportView(table);
		table.setBorder(new LineBorder(new Color(0, 0, 0)));
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(panel, GroupLayout.DEFAULT_SIZE, 259, Short.MAX_VALUE)
					.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 910, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(panel, GroupLayout.DEFAULT_SIZE, 591, Short.MAX_VALUE)
				.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 591, Short.MAX_VALUE)
		);
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(9)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 890, Short.MAX_VALUE)
					.addGap(9))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(4)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 575, Short.MAX_VALUE)
					.addContainerGap())
		);
		panel_1.setLayout(gl_panel_1);
		frame.getContentPane().setLayout(groupLayout);
		
		// Chargement des données de la table des clients depuis la base de données
        PharmacienDAO phDAO = new PharmacienDAO();
        List<Client> clients = phDAO.consulterClient();
        clientModel.loadData(clients);

        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.addWindowListener(new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent e) {
		        frame.dispose();
		    }
		});
		
		
		
		
		 table.addMouseListener(new MouseAdapter() {
	        	@Override
	        	public void mouseClicked(MouseEvent e) {
	        		int line = table.getSelectedRow();
	        		//JOptionPane.showMessageDialog(null, line);
	        		String idClient = table.getModel().getValueAt(line, 0).toString();
	        		String nomClient = table.getModel().getValueAt(line, 1).toString();
	        		String prenomClient = table.getModel().getValueAt(line, 2).toString();
	        		String credit = table.getModel().getValueAt(line, 3).toString();
	        		String codeOrdonnance = table.getModel().getValueAt(line, 4).toString();
	        		
	        		textField.setText(idClient);
	                textField_1.setText(nomClient);
	                textField_2.setText(prenomClient);
	                textField_3.setText(credit);
	                textField_4.setText(codeOrdonnance);
	               
	        		
	        		
	        		
	        	}
	        });
		
		frame.setVisible(true);
		
	}
	
	
	
	
	
	
	
	private boolean existeLigne(JTable table, String value1, String value2, String value3, float value4, String value5) {
	    // Parcourir les lignes du JTable
	    for (int i = 0; i < table.getRowCount(); i++) {
	        // Vérifier si les valeurs des colonnes correspondent
	        String tableValue1 = table.getValueAt(i, 0).toString();
	        String tableValue2 = table.getValueAt(i, 1).toString();
	        String tableValue3 = table.getValueAt(i, 2).toString();
	        float tableValue4 = Float.valueOf((table.getValueAt(i, 3)).toString());
	        String tableValue5 = table.getValueAt(i, 4).toString();


	        
	        
	        if (tableValue1.equals(value1) && tableValue2.equals(value2) && tableValue3.equals(value3) && (String.valueOf(tableValue4).equals(value4)) && tableValue5.equals(value5))  {
	            return true; // La ligne existe déjà
	        }
	    }
	    
	    return false; // Aucune ligne ne correspond
	}
}
