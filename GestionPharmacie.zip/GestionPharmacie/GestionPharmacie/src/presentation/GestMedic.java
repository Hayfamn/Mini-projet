package presentation;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Date;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

import dao.AdministrateurDAO;
import dao.PharmacienDAO;
import metier.Medicament;

public class GestMedic {

	private JFrame frmGestionDesMedicaments;
	private JComboBox textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GestMedic window = new GestMedic();
					window.frmGestionDesMedicaments.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GestMedic() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmGestionDesMedicaments = new JFrame();
		frmGestionDesMedicaments.setTitle("GESTION DES MEDICAMENTS");
		frmGestionDesMedicaments.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\nermine\\eclipse-workspace\\GestionPharmacie\\Logo-Pharmacie.jpg"));
		//frame.setBounds(100, 100, 450, 300);
		frmGestionDesMedicaments.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        
//        // Définition de la taille du JFrame
        frmGestionDesMedicaments.setSize(1540, 760);
        
        JPanel panel = new JPanel();
        panel.setBorder(new LineBorder(new Color(0, 0, 0)));
        
        JLabel lblNewLabel = new JLabel("Code Famille :");
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblNewLabel.setHorizontalAlignment(SwingConstants.TRAILING);
        
        textField = new JComboBox();
        textField.setFont(new Font("Tahoma", Font.BOLD, 13));
        textField.setModel(new DefaultComboBoxModel(new String[] {"Analgésique", "Anti-inflammatoire", "Antibiotique", "Antibactérien", "Antiviral", "Cardiologie", "Dermatologie", "Diététique", "Nutrition", "Endocrinologie", "Hépatologie", "Gynécologie", "Hématologie", "Immunologie", "Neurologie", "Ophtalmologie", "Parasitologie", "Psychiatrie", "Réanimation toxicologie", "Rhumatologie", "Stomatologie", "Urologie", "Vaccin"}));
        
        JLabel lblNewLabel_1 = new JLabel("Code Medicament :");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblNewLabel_1.setHorizontalAlignment(SwingConstants.TRAILING);
        
        textField_1 = new JTextField();
        textField_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
        textField_1.setHorizontalAlignment(SwingConstants.CENTER);
        textField_1.setColumns(10);
        
        JLabel lblNewLabel_2 = new JLabel("Libelle Medicament :");
        lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblNewLabel_2.setHorizontalAlignment(SwingConstants.TRAILING);
        
        textField_2 = new JTextField();
        textField_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
        textField_2.setHorizontalAlignment(SwingConstants.CENTER);
        textField_2.setColumns(10);
        
        JLabel lblNewLabel_3 = new JLabel("Quantite :");
        lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblNewLabel_3.setHorizontalAlignment(SwingConstants.TRAILING);
        
        textField_3 = new JTextField();
        textField_3.setFont(new Font("Tahoma", Font.PLAIN, 13));
        textField_3.setHorizontalAlignment(SwingConstants.CENTER);
        textField_3.setColumns(10);
        
        JLabel lblNewLabel_4 = new JLabel("Prix :");
        lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblNewLabel_4.setHorizontalAlignment(SwingConstants.TRAILING);
        
        textField_4 = new JTextField();
        textField_4.setFont(new Font("Tahoma", Font.PLAIN, 13));
        textField_4.setHorizontalAlignment(SwingConstants.CENTER);
        textField_4.setColumns(10);
        
        JLabel lblNewLabel_5 = new JLabel("Date Livraison :");
        lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblNewLabel_5.setHorizontalAlignment(SwingConstants.TRAILING);
        
        textField_5 = new JTextField();
        textField_5.setFont(new Font("Tahoma", Font.PLAIN, 13));
        textField_5.setHorizontalAlignment(SwingConstants.CENTER);
        textField_5.setColumns(10);
        
        textField_5.setForeground(Color.LIGHT_GRAY);
		textField_5.setText("YYYY-MM-DD");
		textField_5.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(textField_5.getText().equals("YYYY-MM-DD")) {
					textField_5.setText("");
					textField_5.setForeground(Color.black);
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(textField_5.getText().equals("")) {
					textField_5.setText("YYYY-MM-DD");
					textField_5.setForeground(Color.LIGHT_GRAY);
				}
			}
		});
        
        
        JLabel lblNewLabel_6 = new JLabel("Date Expiration :");
        lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblNewLabel_6.setHorizontalAlignment(SwingConstants.TRAILING);
        
        textField_6 = new JTextField();
        textField_6.setFont(new Font("Tahoma", Font.PLAIN, 13));
        textField_6.setHorizontalAlignment(SwingConstants.CENTER);
        textField_6.setColumns(10);
        
        
        textField_6.setForeground(Color.LIGHT_GRAY);
		textField_6.setText("YYYY-MM-DD");
		textField_6.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(textField_6.getText().equals("YYYY-MM-DD")) {
					textField_6.setText("");
					textField_6.setForeground(Color.black);
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(textField_6.getText().equals("")) {
					textField_6.setText("YYYY-MM-DD");
					textField_6.setForeground(Color.LIGHT_GRAY);
				}
			}
		});
        
        
        JLabel lblNewLabel_7 = new JLabel("Stock :");
        lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblNewLabel_7.setHorizontalAlignment(SwingConstants.TRAILING);
        
        textField_7 = new JTextField();
        textField_7.setFont(new Font("Tahoma", Font.PLAIN, 13));
        textField_7.setHorizontalAlignment(SwingConstants.CENTER);
        textField_7.setColumns(10);
        
        
        
        JButton btnNewButton = new JButton("Ajouter Medicament");
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
        JTextField[] textFields = {textField_1, new JTextField( textField.getSelectedItem().toString()), textField_2, textField_3, textField_4, textField_5, textField_6, textField_7};
        
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if (existeLigne(table, textField_1.getText(), textField.getSelectedItem().toString(), textField_2.getText(), Integer.valueOf(textField_3.getText()), Float.valueOf(textField_4.getText()),  Date.valueOf(textField_5.getText()), Date.valueOf(textField_6.getText()), Integer.valueOf(textField_7.getText()) )) {
				    JOptionPane.showMessageDialog(null, "Valeurs déjà existentes !");
				} else {
				    // Ajouter le code pour gérer l'action
					 String codeMedicament = textField_1.getText();
			         String codeFamille = String.valueOf(textField.getSelectedItem());
			         String libelleMedicament = textField_2.getText();
			         int qte = Integer.valueOf(textField_3.getText());
			         float prix = Float.valueOf(textField_4.getText());
			         Date dateLivr = Date.valueOf(textField_5.getText());
			         Date dateExp = Date.valueOf(textField_6.getText());
			         int stock = Integer.valueOf(textField_7.getText());

				    PharmacienDAO phDAO = new PharmacienDAO();
				    AdministrateurDAO admDAO = new AdministrateurDAO();
				    MedicamentModel medicModel = new MedicamentModel();
				    try {
				        // Appeler la fonction d'ajout dans la base de données
				        admDAO.ajoutMedicament(new Medicament(codeMedicament, codeFamille, libelleMedicament, qte, prix, dateLivr, dateExp, stock));

				        // Charger toutes les données depuis la base de données
				        List<Medicament> medic = phDAO.consulterMédicament();

				        // Charger les données dans le modèle de données de la JTable
				        medicModel.loadData(medic);

				        // Rafraîchir la vue de la table
				        table.setModel(medicModel);
				    } catch (Exception ex) {
				        ex.printStackTrace();
				    }
        		}
        	}
        });
        
        
        JButton btnNewButton_1 = new JButton("Modifier Medicament");
        btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
        
        
        
        btnNewButton_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		// Ajouter un code pour gérer l'action
		    	 String codeMedicament = textField_1.getText();
		         String codeFamille = String.valueOf(textField.getSelectedItem());
		         String libelleMedicament = textField_2.getText();
		         int qte = Integer.valueOf(textField_3.getText());
		         float prix = Float.valueOf(textField_4.getText());
		         Date dateLivr = Date.valueOf(textField_5.getText());
		         Date dateExp = Date.valueOf(textField_6.getText());
		         int stock = Integer.valueOf(textField_7.getText());

		         

		         PharmacienDAO phDAO = new PharmacienDAO();
		         AdministrateurDAO admDAO = new AdministrateurDAO();
		         MedicamentModel medicamentModel = new MedicamentModel();
		         try {
		             // Appeler la fonction d'update du medicament dans la base de données
		             admDAO.modifMedicament(new Medicament(codeMedicament, codeFamille, libelleMedicament, qte, prix, dateLivr, dateExp, stock));
		             
		             // Charger toutes les données depuis la base de données
		             List<Medicament> medicaments = phDAO.consulterMédicament();
		             
		            
		             // Charger les données dans le modèle de données de la JTable
		             medicamentModel.loadData(medicaments);
		             
		             // Rafraîchir la vue de la table
		             table.setModel(medicamentModel);
		         } catch(Exception ex) {
		             ex.printStackTrace();
		         }
        	}
        });
        
        
        
        JButton btnNewButton_2 = new JButton("Supprimer Medicament");
        btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 14));
        
        
        
        
        btnNewButton_2.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		// Ajouter un code pour gérer l'action
		    	 String codeMedicament = textField_1.getText();
		         

		    	 PharmacienDAO phDAO = new PharmacienDAO();
		    	 AdministrateurDAO admDAO = new AdministrateurDAO();
		         MedicamentModel medicamentModel = new MedicamentModel();
		         try {
		             // Appeler la fonction de suppression d'un medicament dans la base de données
		             admDAO.supprimMedicament(codeMedicament);
		             
		             // Charger toutes les données depuis la base de données
		             List<Medicament> medicaments = phDAO.consulterMédicament();
		             
		             
		             // Charger les données dans le modèle de données de la JTable
		             medicamentModel.loadData(medicaments);
		             
		             // Rafraîchir la vue de la table
		             table.setModel(medicamentModel);
		         } catch(Exception ex) {
		             ex.printStackTrace();
		         }
        	}
        });
        
        
        
        
        JPanel panel_1 = new JPanel();
        panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
        
        MedicamentModel medicamentModel = new MedicamentModel();
        table = new JTable(medicamentModel);
        table.setBorder(new LineBorder(new Color(0, 0, 0)));
        table.setFont(new Font("Tahoma", Font.PLAIN, 13));
        table.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		int line = table.getSelectedRow();
        		//JOptionPane.showMessageDialog(null, line);
        		String codeMedicament = table.getModel().getValueAt(line, 0).toString();
        		String codeFamille = table.getModel().getValueAt(line, 1).toString();
        		String libelleMedicament = table.getModel().getValueAt(line, 2).toString();
        		String qte = table.getModel().getValueAt(line, 3).toString();
        		String prix = table.getModel().getValueAt(line, 4).toString();
        		String dateLivr = table.getModel().getValueAt(line, 5).toString();
        		String dateExp = table.getModel().getValueAt(line, 6).toString();
        		String stock = table.getModel().getValueAt(line, 7).toString();
        		
        		textField_1.setText(codeMedicament);
                textField.setSelectedItem(codeFamille);
                textField_2.setText(libelleMedicament);
                textField_3.setText(qte);
                textField_4.setText(prix);
                textField_5.setText(dateLivr);
                textField_6.setText(dateExp);
                textField_7.setText(stock);
        		
        		
        		
        	}
        });
        JScrollPane scrollPane = new JScrollPane(table);
		table.setFillsViewportHeight(true);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		GroupLayout groupLayout = new GroupLayout(frmGestionDesMedicaments.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 441, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 1047, Short.MAX_VALUE)
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(panel, GroupLayout.DEFAULT_SIZE, 703, Short.MAX_VALUE)
						.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 703, Short.MAX_VALUE))
					.addContainerGap())
		);
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 1072, Short.MAX_VALUE)
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 815, Short.MAX_VALUE)
		);
		panel_1.setLayout(gl_panel_1);
		
		JLabel lblNewLabel_8 = new JLabel("DT");
		lblNewLabel_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 12));
		
		JButton btnNewButton_3 = new JButton("Enregistrer");
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		
		
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdministrateurDAO.Enregistrer();
			}
		});
		
		JButton btnNewButton_4 = new JButton("Fermer");
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmGestionDesMedicaments.dispose();
			}
		});
		
		
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(25)
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel_7, GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
								.addComponent(lblNewLabel_5, GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
								.addComponent(lblNewLabel_6, GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
								.addGroup(gl_panel.createSequentialGroup()
									.addComponent(lblNewLabel_4, GroupLayout.DEFAULT_SIZE, 131, Short.MAX_VALUE)
									.addGap(18)))
							.addGap(18))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, 143, Short.MAX_VALUE)
							.addGap(24))
						.addGroup(gl_panel.createSequentialGroup()
							.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
								.addComponent(lblNewLabel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
								.addComponent(lblNewLabel_3, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
								.addComponent(lblNewLabel_2))
							.addGap(18)))
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
						.addComponent(textField_1, GroupLayout.DEFAULT_SIZE, 193, Short.MAX_VALUE)
						.addComponent(textField_2, GroupLayout.DEFAULT_SIZE, 193, Short.MAX_VALUE)
						.addComponent(textField, Alignment.LEADING, 0, 193, Short.MAX_VALUE)
						.addComponent(textField_7, GroupLayout.DEFAULT_SIZE, 193, Short.MAX_VALUE)
						.addComponent(textField_6, GroupLayout.DEFAULT_SIZE, 193, Short.MAX_VALUE)
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(lblNewLabel_8, GroupLayout.PREFERRED_SIZE, 51, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED))
						.addComponent(textField_5, GroupLayout.DEFAULT_SIZE, 193, Short.MAX_VALUE)
						.addComponent(textField_3, GroupLayout.DEFAULT_SIZE, 193, Short.MAX_VALUE))
					.addGap(54))
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(117)
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
						.addComponent(btnNewButton_4, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
						.addComponent(btnNewButton_3, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
						.addComponent(btnNewButton_1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
						.addComponent(btnNewButton_2, GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
						.addComponent(btnNewButton, GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE))
					.addGap(121))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(29)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(textField, GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
						.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 21, Short.MAX_VALUE))
					.addGap(7)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE))
					.addGap(19)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(textField_3, GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
						.addComponent(lblNewLabel_3, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addGap(23)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(textField_4, GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
						.addComponent(lblNewLabel_8, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_4, GroupLayout.DEFAULT_SIZE, 21, Short.MAX_VALUE))
					.addGap(23)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(textField_5, GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
						.addComponent(lblNewLabel_5, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addGap(21)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(textField_6, GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
						.addComponent(lblNewLabel_6, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addGap(12)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(textField_7, GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
						.addComponent(lblNewLabel_7, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addGap(47)
					.addComponent(btnNewButton, GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
					.addGap(36)
					.addComponent(btnNewButton_1, GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
					.addGap(42)
					.addComponent(btnNewButton_2, GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
					.addGap(39)
					.addComponent(btnNewButton_3, GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
					.addGap(34)
					.addComponent(btnNewButton_4, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGap(17))
		);
		panel.setLayout(gl_panel);
		frmGestionDesMedicaments.getContentPane().setLayout(groupLayout);

		// Charger les données de la table des clients depuis la base de données
		try (PharmacienDAO phDAO = new PharmacienDAO()) {
		    List<Medicament> ordonnances = phDAO.consulterMédicament();
		    medicamentModel.loadData(ordonnances);
		}catch(Exception ex) {
		    ex.printStackTrace();
		}

        //panel_1.add(table);
		
		frmGestionDesMedicaments.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frmGestionDesMedicaments.addWindowListener(new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent e) {
		        frmGestionDesMedicaments.dispose();
		    }
		});
        
        frmGestionDesMedicaments.setVisible(true);
        
	}
	
	
	
	
	
	
	
	
	private boolean existeLigne(JTable table, String value, String value1, String value2, int value3, float value4, Date value5, Date value6, int value7) {
	    // Parcourir les lignes du JTable
	    for (int i = 0; i < table.getRowCount(); i++) {
	        // Vérifier si les valeurs des colonnes correspondent
	    	String tableValue = table.getValueAt(i, 0).toString();
	        String tableValue1 = table.getValueAt(i, 1).toString();
	        String tableValue2 = table.getValueAt(i, 2).toString();
	        int tableValue3 = Integer.valueOf(table.getValueAt(i, 3).toString());
	        float tableValue4 = Float.valueOf((table.getValueAt(i, 4)).toString());
	        Date tableValue5 = Date.valueOf((table.getValueAt(i, 5)).toString());
	        Date tableValue6 = Date.valueOf(table.getValueAt(i, 6).toString());
	        int tableValue7 = Integer.valueOf(table.getValueAt(i, 7).toString());


	        
	        
	        if (tableValue.equals(value) && tableValue1.equals(value1) && tableValue2.equals(value2) && Integer.valueOf(tableValue3).equals(value3) && Float.valueOf(tableValue4).equals(value4)&& (Date.valueOf(tableValue5.toString()).equals(value5)) && (Date.valueOf(tableValue6.toString()).equals(value6) && Integer.valueOf(tableValue7).equals(value7)))  {
	            return true; // La ligne existe déjà
	        }
	    }
	    
	    return false; // Aucune ligne ne correspond
	}
	
	
	
}
