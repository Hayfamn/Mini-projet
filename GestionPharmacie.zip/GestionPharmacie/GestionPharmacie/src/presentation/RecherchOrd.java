package presentation;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import dao.PharmacienDAO;
import javax.swing.border.LineBorder;
import java.awt.Color;

public class RecherchOrd {

	private JFrame frame;
	private JPanel panel_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RecherchOrd window = new RecherchOrd();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RecherchOrd() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 810, 483);
		frame.setTitle("RECHERCHE ORDONNANCE");
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\nermine\\eclipse-workspace\\SystemeGestionPharmacie\\Logo-Pharmacie.jpg"));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1.setBounds(338, 359, 759, 278);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		JLabel code = new JLabel("CodeOrdonnance : ");
		code.setHorizontalAlignment(SwingConstants.CENTER);
		code.setFont(new Font("Tahoma", Font.BOLD, 16));
		code.setBounds(122, 26, 172, 38);
		panel_1.add(code);
		
		JTextField textField_Code = new JTextField();
		textField_Code.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField_Code.setHorizontalAlignment(SwingConstants.CENTER);
		textField_Code.setBounds(368, 27, 293, 38);
		panel_1.add(textField_Code);
		textField_Code.setColumns(10);
		
		JLabel libelle = new JLabel("LibelleOrdonnance : ");
		libelle.setFont(new Font("Tahoma", Font.BOLD, 16));
		libelle.setBounds(122, 94, 172, 22);
		panel_1.add(libelle);
		
		JTextField textField_Libelle = new JTextField();
		textField_Libelle.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField_Libelle.setHorizontalAlignment(SwingConstants.CENTER);
		textField_Libelle.setBounds(368, 87, 293, 38);
		panel_1.add(textField_Libelle);
		textField_Libelle.setColumns(10);
		
		JLabel date= new JLabel("DateOrdonnance : ");
		date.setFont(new Font("Tahoma", Font.BOLD, 16));
		date.setHorizontalAlignment(SwingConstants.CENTER);
		date.setBounds(122, 153, 158, 22);
		panel_1.add(date);
		
		JTextField textField_Date = new JTextField();
		textField_Date.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField_Date.setHorizontalAlignment(SwingConstants.CENTER);
		textField_Date.setBounds(368, 146, 293, 38);
		panel_1.add(textField_Date);
		textField_Date.setColumns(10);
		
		JLabel alert = new JLabel("");
		alert.setHorizontalAlignment(SwingConstants.CENTER);
		alert.setFont(new Font("Tahoma", Font.BOLD, 16));
		alert.setBounds(101, 295, 578, 61);
		panel_1.add(alert);
		
		PharmacienDAO phDAO = new PharmacienDAO();
		String st = PharmacienPres.textField_1.getText();
		if(!(PharmacienPres.textField_1.getText().isEmpty()) && PharmacienPres.textField_1.getText().equals(phDAO.recherchOrdonnance(st).get(0).getCodeOrdonnance())) {
			
				phDAO.recherchOrdonnance(st);
				alert.setText("Ordonnance existante !");
				textField_Code.setText(phDAO.recherchOrdonnance(st).get(0).getCodeOrdonnance());
				textField_Libelle.setText(phDAO.recherchOrdonnance(st).get(0).getLibelleOrdonnance());
				textField_Date.setText(String.valueOf(phDAO.recherchOrdonnance(st).get(0).getDateOrdonnance()));
				
		}		
	   else if(phDAO.recherchMedicament(st).isEmpty()==true){
					alert.setText("Aucun resultat !");
					textField_Code.setText(null);
					textField_Libelle.setText(null);
					textField_Date.setText(null);
					
			}
				
				
			
		else {
			JOptionPane.showMessageDialog(null, "Erreur de saisir !");
		
	}
		
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.addWindowListener(new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent e) {
		        frame.dispose();
		    }
		});
		
		frame.setVisible(true);
		
	}

}
