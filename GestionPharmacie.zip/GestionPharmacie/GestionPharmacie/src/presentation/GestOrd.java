package presentation;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Date;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

import dao.AdministrateurDAO;
import dao.PharmacienDAO;
import metier.Ordonnance;
import javax.swing.LayoutStyle.ComponentPlacement;

public class GestOrd {

	private JFrame frame;
	private final JPanel panel = new JPanel();
	private JTable table;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField txtYyyymmdd;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GestOrd window = new GestOrd();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GestOrd() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		
		
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\nermine\\OneDrive\\Bureau\\src_img\\Logo-Pharmacie.jpg"));
        frame.setTitle("GESTION DES ORDONNANCES");
		frame.setBounds(100, 100, 1363, 824);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel leftPanel = new JPanel();
		leftPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		leftPanel.setPreferredSize(new Dimension(463, 742));
		
		
		

		

		JButton addBtn = new JButton("Ajouter un ordonnance");
		addBtn.setFont(new Font("Tahoma", Font.BOLD, 14));
		
        JTextField[] textFields = {textField, textField_1, txtYyyymmdd};

		addBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 PharmacienDAO phDAO = new PharmacienDAO();
		         OrdonnanceModel ordonnanceModel = new OrdonnanceModel();
		         AdministrateurDAO admDAO = new AdministrateurDAO();
		         
	    	     
	    	     if (existeLigne(table, textField.getText(), textField_1.getText(), Date.valueOf(txtYyyymmdd.getText()))) {
					    JOptionPane.showMessageDialog(null, "Valeurs déjà existentes !");
					} else {
					    // Ajouter le code pour gérer l'action
						String code = textField.getText();
			    	     String libelle = textField_1.getText();
			    	     String date = txtYyyymmdd.getText();

					    try {
					        // Appeler la fonction d'ajout dans la base de données
					        phDAO.ajoutOrdonnance(new Ordonnance(code, libelle, Date.valueOf(date)));

					        // Charger toutes les données depuis la base de données
					        List<Ordonnance> ordo = phDAO.consulterOrdonnance();

					        // Charger les données dans le modèle de données de la JTable
					        ordonnanceModel.loadData(ordo);

					        // Rafraîchir la vue de la table
					        table.setModel(ordonnanceModel);
					    } catch (Exception ex) {
					        ex.printStackTrace();
					    }
	         		}}});
		
		
		
		
		
		

		JButton modifyBtn = new JButton("Modifier un ordonnance");
		modifyBtn.setFont(new Font("Tahoma", Font.BOLD, 14));
		modifyBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {

		    	PharmacienDAO phDAO = new PharmacienDAO();
		         OrdonnanceModel ordonnanceModel = new OrdonnanceModel();
		         String code = textField.getText();
	    	     String libelle = textField_1.getText();
	    	     String date = txtYyyymmdd.getText();
		         try {
		        	 
		        	 
		             // Appeler la fonction d'update d'une ordonnance dans la base de données
		             phDAO.modifOrdonnance(new Ordonnance(code, libelle, Date.valueOf(date)));
		             
		             // Charger toutes les données depuis la base de données
		             List<Ordonnance> ordonnances = phDAO.consulterOrdonnance();
		             
		             
		             // Charger les données dans le modèle de données de la JTable
		             ordonnanceModel.loadData(ordonnances);
		             
		             // Rafraîchir la vue de la table
		             table.setModel(ordonnanceModel);
		         } catch(Exception ex) {
		             ex.printStackTrace();
		         }
		    	

		    }});
		
		
		
		

		JButton deleteBtn = new JButton("Supprimer un ordonnance");
		deleteBtn.setFont(new Font("Tahoma", Font.BOLD, 14));
		deleteBtn.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	PharmacienDAO phDAO = new PharmacienDAO();
		         OrdonnanceModel ordonnanceModel = new OrdonnanceModel();
		         String code = textField.getText();
	    	     String libelle = textField_1.getText();
	    	     String date = txtYyyymmdd.getText();
		         try {
		        	 
		        	 
		             // Appeler la fonction de suppression d'une ordonnance dans la base de données
		             phDAO.supprimOrdonnance(code);
		             
		             // Charger toutes les données depuis la base de données
		             List<Ordonnance> ordonnances = phDAO.consulterOrdonnance();
		             
		             
		             // Charger les données dans le modèle de données de la JTable
		             ordonnanceModel.loadData(ordonnances);
		             
		             // Rafraîchir la vue de la table
		             table.setModel(ordonnanceModel);
		         } catch(Exception ex) {
		             ex.printStackTrace();
		         }
		    	
		    }
		});
		
		JLabel lblNewLabel = new JLabel("codeOrdonnance :");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		JLabel lblNewLabel_1 = new JLabel("libelleOrdonnance :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		JLabel lblNewLabel_2 = new JLabel("dateOrdonnance :");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		
		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField_1.setColumns(10);
		
		//DateFormat format = new SimpleDateFormat("YYYY-MM-DD");
		txtYyyymmdd = new JTextField();
		txtYyyymmdd.setHorizontalAlignment(SwingConstants.CENTER);
		txtYyyymmdd.setFont(new Font("Tahoma", Font.PLAIN, 13));
		txtYyyymmdd.setForeground(Color.LIGHT_GRAY);
		txtYyyymmdd.setText("YYYY-MM-DD");
		txtYyyymmdd.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if(txtYyyymmdd.getText().equals("YYYY-MM-DD")) {
					txtYyyymmdd.setText("");
					txtYyyymmdd.setForeground(Color.black);
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				if(txtYyyymmdd.getText().equals("")) {
					txtYyyymmdd.setText("YYYY-MM-DD");
					txtYyyymmdd.setForeground(Color.LIGHT_GRAY);
				}
			}
		});
		txtYyyymmdd.setActionCommand("");
		txtYyyymmdd.setToolTipText("YYYY-MM-DD");
		txtYyyymmdd.setColumns(10);
		
		

		JPanel rightPanel = new JPanel();
		rightPanel.setBorder(new LineBorder(new Color(0, 0, 0)));

		OrdonnanceModel ordonnanceModel = new OrdonnanceModel();
		table = new JTable(ordonnanceModel);
		table.setBorder(new LineBorder(new Color(0, 0, 0)));
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int ligne = table.getSelectedRow();
				String codeOrdonnance = table.getModel().getValueAt(ligne, 0).toString();
				String libelleOrdonnance = table.getModel().getValueAt(ligne, 1).toString();
				String dateOrdonnance = table.getModel().getValueAt(ligne, 2).toString();
				textField.setText(codeOrdonnance);
				textField_1.setText(libelleOrdonnance);
				txtYyyymmdd.setText(dateOrdonnance);
			}
		});
		table.setFont(new Font("Tahoma", Font.PLAIN, 13));
		

		
		JScrollPane scrollPane = new JScrollPane(table);
		table.setFillsViewportHeight(true);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(leftPanel, GroupLayout.DEFAULT_SIZE, 463, Short.MAX_VALUE)
					.addGap(7)
					.addComponent(rightPanel, GroupLayout.PREFERRED_SIZE, 879, GroupLayout.PREFERRED_SIZE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(leftPanel, GroupLayout.DEFAULT_SIZE, 787, Short.MAX_VALUE)
				.addComponent(rightPanel, GroupLayout.DEFAULT_SIZE, 787, Short.MAX_VALUE)
		);
		GroupLayout gl_rightPanel = new GroupLayout(rightPanel);
		gl_rightPanel.setHorizontalGroup(
			gl_rightPanel.createParallelGroup(Alignment.LEADING)
				.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 886, Short.MAX_VALUE)
		);
		gl_rightPanel.setVerticalGroup(
			gl_rightPanel.createParallelGroup(Alignment.LEADING)
				.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 787, Short.MAX_VALUE)
		);
		rightPanel.setLayout(gl_rightPanel);
		
		JPanel panel_1 = new JPanel();
		GroupLayout gl_leftPanel = new GroupLayout(leftPanel);
		gl_leftPanel.setHorizontalGroup(
			gl_leftPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_leftPanel.createSequentialGroup()
					.addGap(10)
					.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE)
					.addGap(10)
					.addComponent(textField, GroupLayout.DEFAULT_SIZE, 227, Short.MAX_VALUE)
					.addGap(46))
				.addGroup(gl_leftPanel.createSequentialGroup()
					.addGap(10)
					.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE)
					.addGap(10)
					.addComponent(textField_1, GroupLayout.DEFAULT_SIZE, 227, Short.MAX_VALUE)
					.addGap(46))
				.addGroup(gl_leftPanel.createSequentialGroup()
					.addGap(10)
					.addComponent(lblNewLabel_2, GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE)
					.addGap(10)
					.addComponent(txtYyyymmdd, GroupLayout.DEFAULT_SIZE, 227, Short.MAX_VALUE)
					.addGap(46))
				.addGroup(Alignment.TRAILING, gl_leftPanel.createSequentialGroup()
					.addGap(75)
					.addGroup(gl_leftPanel.createParallelGroup(Alignment.TRAILING)
						.addComponent(deleteBtn, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 294, Short.MAX_VALUE)
						.addComponent(modifyBtn, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 294, Short.MAX_VALUE)
						.addComponent(addBtn, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 294, Short.MAX_VALUE))
					.addGap(92))
				.addGroup(gl_leftPanel.createSequentialGroup()
					.addContainerGap()
					.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 441, Short.MAX_VALUE)
					.addContainerGap())
		);
		gl_leftPanel.setVerticalGroup(
			gl_leftPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_leftPanel.createSequentialGroup()
					.addGap(80)
					.addGroup(gl_leftPanel.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
						.addComponent(textField, GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE))
					.addGap(76)
					.addGroup(gl_leftPanel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_leftPanel.createSequentialGroup()
							.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 17, Short.MAX_VALUE)
							.addGap(11))
						.addComponent(textField_1, GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE))
					.addGap(78)
					.addGroup(gl_leftPanel.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_2, GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
						.addComponent(txtYyyymmdd, GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE))
					.addGap(97)
					.addComponent(addBtn, GroupLayout.DEFAULT_SIZE, 49, Short.MAX_VALUE)
					.addGap(48)
					.addComponent(modifyBtn, GroupLayout.DEFAULT_SIZE, 49, Short.MAX_VALUE)
					.addGap(48)
					.addComponent(deleteBtn, GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 115, Short.MAX_VALUE)
					.addContainerGap())
		);
		
		JButton btnNewButton = new JButton("Consulter les medicaments d'une ordonnance ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MedicOrd medOrd = new MedicOrd();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(10)
					.addComponent(btnNewButton, GroupLayout.DEFAULT_SIZE, 421, Short.MAX_VALUE)
					.addGap(10))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(43)
					.addComponent(btnNewButton, GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
					.addGap(34))
		);
		panel_1.setLayout(gl_panel_1);
		leftPanel.setLayout(gl_leftPanel);
		frame.getContentPane().setLayout(groupLayout);

		// Charger les données de la table des clients depuis la base de données
		try (PharmacienDAO phDAO = new PharmacienDAO()) {
		    List<Ordonnance> ordonnances = phDAO.consulterOrdonnance();
		    ordonnanceModel.loadData(ordonnances);
		}catch(Exception ex) {
		    ex.printStackTrace();
		}

		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.addWindowListener(new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent e) {
		        frame.dispose();
		    }
		});
		
		frame.setVisible(true);
	    
		
	}
	
	
	
	
	
	
	
	private boolean existeLigne(JTable table, String value, String value1, Date value2) {
	    // Parcourir les lignes du JTable
	    for (int i = 0; i < table.getRowCount(); i++) {
	        // Vérifier si les valeurs des colonnes correspondent
	    	String tableValue = table.getValueAt(i, 0).toString();
	        String tableValue1 = table.getValueAt(i, 1).toString();
	        Date tableValue2 = Date.valueOf((table.getValueAt(i, 2)).toString());
	        


	        
	        
	        if (tableValue.equals(value) && tableValue1.equals(value1) && (Date.valueOf(tableValue2.toString()).equals(value2))) {
	            return true; // La ligne existe déjà
	        }
	    }
	    
	    return false; // Aucune ligne ne correspond
	}
}
