package presentation;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;

import metier.Ordonnance;

public class OrdonnanceModel extends AbstractTableModel{
	private String[] nomColonnes=new String[] {"codeOrdonnance", "libelleOrdonnance", "dateOrdonnance"};
	private Vector<String[]> rows=new Vector<String[]>();
    private List<Ordonnance> ordonnances = new ArrayList<>();

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return nomColonnes.length;
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return rows.size();
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		return rows.get(rowIndex)[columnIndex];
	}
	public String getColumnName(int column)
	{
		return nomColonnes[column];
	}
    public void loadData(List<Ordonnance> ordonnances)
    {
    	rows=new Vector<String[]>();
    	for(Ordonnance ordo : ordonnances)
    	{
    		rows.add(new String[] {
    				ordo.getCodeOrdonnance(), ordo.getLibelleOrdonnance(),
    				String.valueOf(ordo.getDateOrdonnance())
    				});
    	}
    	fireTableChanged(null);
    }
    

    }

	


