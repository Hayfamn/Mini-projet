package presentation;
import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import dao.PharmacienDAO;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Recherche extends JFrame{

	private JFrame frmRecherche;
	private JPanel panel_1;
	private JTextField textField_Prix;
	private JTextField textField_Stock;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Recherche window = new Recherche();
					window.frmRecherche.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Recherche() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmRecherche = new JFrame();
		frmRecherche.setResizable(false);
		frmRecherche.setTitle("RECHERCHE MEDICAMENT");
		frmRecherche.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\nermine\\eclipse-workspace\\SystemeGestionPharmacie\\Logo-Pharmacie.jpg"));
		frmRecherche.setBounds(100, 100, 810, 654);
		frmRecherche.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		
		
		
		panel_1 = new JPanel();
		panel_1.setBounds(338, 359, 759, 278);
		frmRecherche.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		JLabel code = new JLabel("Code : ");
		code.setHorizontalAlignment(SwingConstants.CENTER);
		code.setFont(new Font("Tahoma", Font.BOLD, 16));
		code.setBounds(75, 26, 138, 38);
		panel_1.add(code);
		
		JTextField textField_Code = new JTextField();
		textField_Code.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField_Code.setHorizontalAlignment(SwingConstants.CENTER);
		textField_Code.setBounds(285, 29, 293, 38);
		panel_1.add(textField_Code);
		textField_Code.setColumns(10);
		
		JLabel codeFamille = new JLabel("CodeFamille : ");
		codeFamille.setFont(new Font("Tahoma", Font.BOLD, 16));
		codeFamille.setBounds(64, 93, 149, 22);
		panel_1.add(codeFamille);
		
		JTextField textField_CodeFamille = new JTextField();
		textField_CodeFamille.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField_CodeFamille.setHorizontalAlignment(SwingConstants.CENTER);
		textField_CodeFamille.setBounds(285, 88, 293, 38);
		panel_1.add(textField_CodeFamille);
		textField_CodeFamille.setColumns(10);
		
		JLabel libelle = new JLabel("Libelle : ");
		libelle.setHorizontalAlignment(SwingConstants.CENTER);
		libelle.setFont(new Font("Tahoma", Font.BOLD, 16));
		libelle.setBounds(85, 210, 114, 38);
		panel_1.add(libelle);
		
		JTextField textField_Libelle = new JTextField();
		textField_Libelle.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField_Libelle.setHorizontalAlignment(SwingConstants.CENTER);
		textField_Libelle.setBounds(285, 210, 293, 38);
		panel_1.add(textField_Libelle);
		textField_Libelle.setColumns(10);
		
		JLabel qte= new JLabel("Quantite : ");
		qte.setFont(new Font("Tahoma", Font.BOLD, 16));
		qte.setHorizontalAlignment(SwingConstants.CENTER);
		qte.setBounds(75, 153, 114, 22);
		panel_1.add(qte);
		
		JTextField textField_Quantite = new JTextField();
		textField_Quantite.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField_Quantite.setHorizontalAlignment(SwingConstants.CENTER);
		textField_Quantite.setBounds(285, 148, 293, 38);
		panel_1.add(textField_Quantite);
		textField_Quantite.setColumns(10);
		
		
		JTextField textField_DateExp = new JTextField();
		textField_DateExp.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField_DateExp.setHorizontalAlignment(SwingConstants.CENTER);
		textField_DateExp.setBounds(285, 402, 293, 38);
		panel_1.add(textField_DateExp);
		textField_DateExp.setColumns(10);
		
		JLabel dateExp = new JLabel("DateExp : ");
		dateExp.setFont(new Font("Tahoma", Font.BOLD, 16));
		dateExp.setHorizontalAlignment(SwingConstants.CENTER);
		dateExp.setBounds(85, 418, 105, 22);
		panel_1.add(dateExp);
		
		JLabel dateLivr = new JLabel("DateLivr : ");
		dateLivr.setHorizontalAlignment(SwingConstants.CENTER);
		dateLivr.setFont(new Font("Tahoma", Font.BOLD, 16));
		dateLivr.setBounds(85, 345, 95, 22);
		panel_1.add(dateLivr);
		
		JTextField textField_DateLivr = new JTextField();
		textField_DateLivr.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField_DateLivr.setHorizontalAlignment(SwingConstants.CENTER);
		textField_DateLivr.setBounds(285, 337, 293, 43);
		panel_1.add(textField_DateLivr);
		textField_DateLivr.setColumns(10);
		
		JLabel alert = new JLabel("");
		alert.setHorizontalAlignment(SwingConstants.CENTER);
		alert.setFont(new Font("Tahoma", Font.BOLD, 16));
		alert.setBounds(105, 530, 578, 61);
		panel_1.add(alert);
		
		JLabel prix = new JLabel("Prix :");
		prix.setFont(new Font("Tahoma", Font.BOLD, 16));
		prix.setBounds(129, 274, 95, 31);
		panel_1.add(prix);
		
		textField_Prix = new JTextField();
		textField_Prix.setHorizontalAlignment(SwingConstants.CENTER);
		textField_Prix.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField_Prix.setBounds(285, 273, 293, 38);
		panel_1.add(textField_Prix);
		textField_Prix.setColumns(10);
		
		JLabel stock = new JLabel("Stock : ");
		stock.setFont(new Font("Tahoma", Font.BOLD, 16));
		stock.setBounds(115, 481, 84, 22);
		panel_1.add(stock);
		
		textField_Stock = new JTextField();
		textField_Stock.setHorizontalAlignment(SwingConstants.CENTER);
		textField_Stock.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textField_Stock.setBounds(285, 466, 293, 38);
		panel_1.add(textField_Stock);
		textField_Stock.setColumns(10);
		
		PharmacienDAO phDAO = new PharmacienDAO();
		String st = PharmacienPres.textField.getText();
		
		if(phDAO.recherchMedicament(st).isEmpty()==true){
			alert.setText("Aucun resultat !");
			textField_Code.setText(null);
			textField_CodeFamille.setText(null);
			textField_Libelle.setText(null);
			textField_Quantite.setText(null);
			textField_Prix.setText(null);
			    textField_DateExp.setText(null);
			textField_DateLivr.setText(null);
			textField_Stock.setText(null);
		
	    }
		else if(!(PharmacienPres.textField.getText().isEmpty()) && PharmacienPres.textField.getText().equals(phDAO.recherchMedicament(st).get(0).getCodeMedicament())) {
			
				phDAO.recherchMedicament(st);
				alert.setText("Medicament existant !");
				textField_Code.setText(phDAO.recherchMedicament(st).get(0).getCodeMedicament());
				textField_CodeFamille.setText(phDAO.recherchMedicament(st).get(0).getCodeFamille());
				textField_Libelle.setText(phDAO.recherchMedicament(st).get(0).getLibelleMedicament());
				textField_Quantite.setText(String.valueOf(phDAO.recherchMedicament(st).get(0).getQte()));
				textField_Prix.setText(String.valueOf(phDAO.recherchMedicament(st).get(0).getPrix()));
				textField_DateLivr.setText(String.valueOf(phDAO.recherchMedicament(st).get(0).getDateLivr()));
				textField_DateExp.setText(String.valueOf(phDAO.recherchMedicament(st).get(0).getDateExp()));
				textField_Stock.setText(String.valueOf(phDAO.recherchMedicament(st).get(0).getStock()));
				
		}		
	   
				
				
			
		else {
			JOptionPane.showMessageDialog(null, "Erreur de saisir !");
		
	}
		
		
		frmRecherche.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frmRecherche.addWindowListener(new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent e) {
		        frmRecherche.dispose();
		    }
		});
		frmRecherche.setVisible(true);
		
		
 }

	}

	
