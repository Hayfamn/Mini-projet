package metier;

import java.util.*;

/**
 * 
 */
public class Medicament {

    

    /**
     * 
     */
    private String codeMedicament;

    /**
     * 
     */
    private String codeFamille;

    /**
     * 
     */
    private String libelleMedicament;

    /**
     * 
     */
    private int qte;

    /**
     * 
     */
    private float prix;
    
    /**
     * 
     */
    private java.sql.Date dateLivr;

    /**
     * 
     */
    private java.sql.Date dateExp;

    /**
     * 
     */
    private int stock;

    /**
     * 
     */
    
    /**
     * Default constructor
     */
    public Medicament() {
    	super();
    }
    
    

    /**
     * @param codeMedicament 
     * @param codeFamille 
     * @param libelleMedicament 
     * @param qte
     * @param prix
     * @param dateLivr 
     * @param dateExp 
     * @param stock
     */
    public Medicament(String codeMedicament, String codeFamille, String libelleMedicament, int qte, float prix, java.sql.Date dateLivr, java.sql.Date dateExp, int stock) {
        // TODO implement here
    	this.codeMedicament=codeMedicament;
    	this.codeFamille=codeFamille;
    	this.libelleMedicament=libelleMedicament;
    	this.qte=qte;
    	this.prix=prix;
    	this.dateLivr=dateLivr;
    	this.dateExp=dateExp;
    	this.stock=stock;
    }

    /**
     * @return
     */
    public String getCodeMedicament() {
        // TODO implement here
        return codeMedicament;
    }

    /**
     * @return
     */
    public String getCodeFamille() {
        // TODO implement here
        return codeFamille;
    }

    /**
     * @return
     */
    public String getLibelleMedicament() {
        // TODO implement here
        return libelleMedicament;
    }

    /**
     * @return
     */
    public int getQte() {
        // TODO implement here
        return qte;
    }

    /**
     * @return
     */
    public float getPrix() {
    	return prix;
    }
    
    /**
     * 
     * @return
     */
    public java.sql.Date getDateLivr() {
        // TODO implement here
        return dateLivr;
    }

    /**
     * @return
     */
    public java.sql.Date getDateExp() {
        // TODO implement here
        return dateExp;
    }

    /**
     * @return
     */
    public int getStock() {
        // TODO implement here
        return stock;
    }

    /**
     * @param codeMedicament 
     * @return
     */
    public void setCodeMedicament(String codeMedicament) {
        // TODO implement here
        this.codeMedicament=codeMedicament;
    }

    /**
     * @param codeFamille 
     * @return
     */
    public void setCodeFamille(String codeFamille) {
        // TODO implement here
        this.codeFamille=codeFamille;
    }

    /**
     * @param libelleMedicament 
     * @return
     */
    public void setLibelleMedicament(String libelleMedicament) {
        // TODO implement here
        this.libelleMedicament=libelleMedicament;
    }

    /**
     * @param qte 
     * @return
     */
    public void setQte(int qte) {
        // TODO implement here
        this.qte=qte;
    }
    /**
     * @param prix
     * @return
     */
    
    public void setPrix(float prix) {
    	this.prix=prix;
    }

    /**
     * @param dateLivr 
     * @return
     */
    public void setDateLivr(java.sql.Date dateLivr) {
        // TODO implement here
        this.dateLivr=dateLivr;
    }

    /**
     * @param dateExp 
     * @return
     */
    public void setDateExp(java.sql.Date dateExp) {
        // TODO implement here
        this.dateExp=dateExp;
    }

    /**
     * @param stock 
     * @return
     */
    public void setStock(int stock) {
        // TODO implement here
        this.stock=stock;
    }



	@Override
	public String toString() {
		return "Medicament [codeMedicament=" + codeMedicament + ", codeFamille=" + codeFamille + ", libelleMedicament="
				+ libelleMedicament + ", qte=" + qte + ", prix=" + prix + ", dateLivr=" + dateLivr + ", dateExp="
				+ dateExp + ", stock=" + stock + "]";
	}
    
    
    

}