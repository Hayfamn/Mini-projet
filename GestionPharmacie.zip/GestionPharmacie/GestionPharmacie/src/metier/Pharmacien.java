package metier;

import java.util.*;

/**
 * 
 */
public class Pharmacien {

    

    /**
     * 
     */
    private int idPharmacien;

    /**
     * 
     */
    private String nomPharmacien;

    /**
     * 
     */
    private String prenomPharmacien;

    /**
     * 
     */
    private String adressePharmacien;

    /**
     * 
     */
    private int télPharmacien;

    /**
     * 
     */
    private String login;

    /**
     * 
     */
    private String passwd;

    /**
     * 
     */
    /**
     * Default constructor
     */
    public Pharmacien() {
    	super();
    }

    /**
     * @param id 
     * @param nom 
     * @param prenom 
     * @param adresse 
     * @param telephone 
     * @param log 
     * @param passwd
     */
    public Pharmacien(int id, String nom, String prenom, String adresse, int telephone, String log, String passwd) {
        // TODO implement here
    	idPharmacien=id;
    	nomPharmacien=nom;
    	prenomPharmacien=prenom;
    	adressePharmacien=adresse;
    	télPharmacien=telephone;
    	login=log;
    	this.passwd=passwd;
    }

    /**
     * @return
     */
    public int getId() {
        // TODO implement here
        return idPharmacien;
    }

    /**
     * @return
     */
    public String getNom() {
        // TODO implement here
        return nomPharmacien;
    }

    /**
     * @return
     */
    public String getPrenom() {
        // TODO implement here
        return prenomPharmacien;
    }

    /**
     * @return
     */
    public String getAdresse() {
        // TODO implement here
        return adressePharmacien;
    }

    /**
     * @return
     */
    public int getTelephone() {
        // TODO implement here
        return télPharmacien;
    }

    /**
     * @return
     */
    public String getLogin() {
        // TODO implement here
        return login;
    }

    /**
     * @return
     */
    public String getPassword() {
        // TODO implement here
        return passwd;
    }

    /**
     * @param id 
     * @return
     */
    public void setId(int id) {
        // TODO implement here
        idPharmacien=id;
    }

    /**
     * @param nom 
     * @return
     */
    public void setNom(String nom) {
        // TODO implement here
        nomPharmacien=nom;
    }

    /**
     * @param prenom 
     * @return
     */
    public void setPrenom(String prenom) {
        // TODO implement here
        prenomPharmacien=prenom;
    }

    /**
     * @param adresse 
     * @return
     */
    public void setAdresse(String adresse) {
        // TODO implement here
        adressePharmacien=adresse;
    }

    /**
     * @param login 
     * @return
     */
    public void setLogin(String login) {
        // TODO implement here
        this.login=login;
    }

    /**
     * @param password 
     * @return
     */
    public void setPassword(String password) {
        // TODO implement here
        passwd=password;
    }

	@Override
	public String toString() {
		return "Pharmacien [idPharmacien=" + idPharmacien + ", nomPharmacien=" + nomPharmacien + ", prenomPharmacien="
				+ prenomPharmacien + ", adressePharmacien=" + adressePharmacien + ", télPharmacien=" + télPharmacien
				+ ", login=" + login + ", passwd=" + passwd + "]";
	}
    
    
    


}