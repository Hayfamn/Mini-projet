package metier;

import java.util.*;

/**
 * 
 */
public class Ordonnance {

    

    /**
     * 
     */
    private String codeOrdonnance;

    /**
     * 
     */
    private String libelleOrdonnance;

    /**
     * 
     */
    private java.sql.Date dateOrdonnance;

    /**
     * 
     */
    
    /**
     * Default constructor
     */
    public Ordonnance() {
    	super();
    }
    
    

    /**
     * @param codeOrdonnance 
     * @param libelleOrdonnance 
     * @param dateOrdonnance
     */
    public Ordonnance(String codeOrdonnance, String libelleOrdonnance, java.sql.Date dateOrdonnance) {
        // TODO implement here
    	this.codeOrdonnance=codeOrdonnance;
    	this.libelleOrdonnance=libelleOrdonnance;
    	this.dateOrdonnance=dateOrdonnance;
    }

    /**
     * @return
     */
    public String getCodeOrdonnance() {
        // TODO implement here
        return codeOrdonnance;
    }

    /**
     * @return
     */
    public String getLibelleOrdonnance() {
        // TODO implement here
        return libelleOrdonnance;
    }

    /**
     * @return
     */
    public java.sql.Date getDateOrdonnance() {
        // TODO implement here
        return dateOrdonnance;
    }

    /**
     * @param codeOrdonnance 
     * @return
     */
    public void setCodeOrdonnance(String codeOrdonnance) {
        // TODO implement here
        this.codeOrdonnance=codeOrdonnance;
    }

    /**
     * @param libelleOrdonnance 
     * @return
     */
    public void setLibelleOrdonnance(String libelleOrdonnance) {
        // TODO implement here
        this.libelleOrdonnance=libelleOrdonnance;
    }

    /**
     * @param dateOrdonnance 
     * @return
     */
    public void setDateOrdonnance(java.sql.Date dateOrdonnance) {
        // TODO implement here
        this.dateOrdonnance=dateOrdonnance;
    }



	@Override
	public String toString() {
		return "Ordonnance [codeOrdonnance=" + codeOrdonnance + ", libelleOrdonnance=" + libelleOrdonnance
				+ ", dateOrdonnance=" + dateOrdonnance + "]";
	}
    
    
    

}