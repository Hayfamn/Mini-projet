package metier;

import java.util.*;

/**
 * 
 */
public class Administrateur extends Pharmacien {
	



	private int id;
	private String nom;
	private String prenom;
	private String adresse;
	private int telephone;
	private String log;
	private String passwd;

    /**
     * Default constructor
     */
    public Administrateur() {
    	super();
    }

    

    /**
     * @param id 
     * @param nom 
     * @param prenom 
     * @param adresse 
     * @param telephone 
     * @param log 
     * @param passwd
     */
   public Administrateur(int id, String nom, String prenom, String adresse, int telephone, String log, String passwd) {
        // TODO implement here
    	this.id=id;
    	this.nom=nom;
    	this.prenom=prenom;
    	this.adresse=adresse;
    	this.telephone=telephone;
    	this.log=log;
    	this.passwd=passwd;
    	
   }
    	@Override
    	public String toString() {
    		return "Administrateur [id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", adresse=" + adresse
    				+ ", telephone=" + telephone + ", log=" + log + ", passwd=" + passwd + "]";
    	
    }


}