package metier;

import java.util.*;

/**
 * 
 */
public class Client {

    

    /**
     * 
     */
    private int idClient;

    /**
     * 
     */
    private String nomClient;

    /**
     * 
     */
    private String prenomClient;

    /**
     * 
     */
    private String codeOrdonnance;

    /**
     * 
     */
    private float credit;

    /**
     * 
     */
    
    /**
     * Default constructor
     */
    public Client() {
    	super();
    }
    
  

    /**
     * @param idClient 
     * @param nomClient 
     * @param prenomClient 
     * @param codeOrdonnance
     */
    public  Client(int idClient, String nomClient, String prenomClient, String codeOrdonnance, float credit) {
        // TODO implement here
    	this.idClient=idClient;
    	this.nomClient=nomClient;
    	this.prenomClient=prenomClient;
    	this.codeOrdonnance=codeOrdonnance;
    	this.credit=credit;
    }

    /**
     * @return
     */
    public int getIdClient() {
        // TODO implement here
        return idClient;
    }

    /**
     * @return
     */
    public String getNomClient() {
        // TODO implement here
        return nomClient;
    }

    /**
     * @return
     */
    public String getPrenomClient() {
        // TODO implement here
        return prenomClient;
    }

    /**
     * @return
     */
    public String getCodeOrdonnance() {
        // TODO implement here
        return codeOrdonnance;
    }

    /**
     * @return
     */
    public float getCredit() {
        // TODO implement here
        return credit;
    }

    /**
     * @param idClient 
     * @return
     */
    public void setIdClient(int idClient) {
        // TODO implement here
        this.idClient=idClient;
    }

    /**
     * @param nomClient 
     * @return
     */
    public void setNomClient(String nomClient) {
        // TODO implement here
        this.nomClient=nomClient;
    }

    /**
     * @param prenomClient 
     * @return
     */
    public void setPrenomClient(String prenomClient) {
        // TODO implement here
        this.prenomClient=prenomClient;
    }

    /**
     * @param codeOrdonnance 
     * @return
     */
    public void setCodeOrdonnance(String codeOrdonnance) {
        // TODO implement here
        this.codeOrdonnance=codeOrdonnance;
    }

    /**
     * @param credit 
     * @return
     */
    public void setCredit(float credit) {
        // TODO implement here
        this.credit=credit;
    }



	@Override
	public String toString() {
		return "Client [idClient=" + idClient + ", nomClient=" + nomClient + ", prenomClient=" + prenomClient
				+ ", codeOrdonnance=" + codeOrdonnance + ", credit=" + credit + "]";
	}
    
    
    

}