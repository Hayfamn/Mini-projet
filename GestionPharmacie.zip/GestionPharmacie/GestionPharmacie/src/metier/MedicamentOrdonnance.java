package metier;

import java.util.*;

/**
 * 
 */
public class MedicamentOrdonnance {

    

    /**
     * 
     */
    

    /**
     * 
     */
    private String codeMedicament;

    /**
     * 
     */
    private String codeOrdonnance;

    /**
     * 
     */
    private String nomMedicament;

    /**
     * 
     */
    private int quantite;

    /**
     * 
     */
    private String dosage;

    /**
     * 
     */
    
    /**
     * Default constructor
     */
    public MedicamentOrdonnance() {
    	super();
    }
    
    

    /**
     * @param codeMedicament 
     * @param codeOrdonnance 
     * @param nomMedicament 
     * @param quantite 
     * @param dosage
     */
    public  MedicamentOrdonnance(String codeMedicament, String codeOrdonnance, String nomMedicament, int quantite, String dosage) {
        // TODO implement here
    	this.codeMedicament=codeMedicament;
    	this.codeOrdonnance=codeOrdonnance;
    	this.nomMedicament=nomMedicament;
    	this.quantite=quantite;
    	this.dosage=dosage;
    }

   

    /**
     * @return
     */
    public String getCodeMedicament() {
        // TODO implement here
        return codeMedicament;
    }

    /**
     * @return
     */
    public String getCodeOrdonnance() {
        // TODO implement here
        return codeOrdonnance;
    }

    /**
     * @return
     */
    public String getNomMedicament() {
        // TODO implement here
        return nomMedicament;
    }

    /**
     * @return
     */
    public int getQuantite() {
        // TODO implement here
        return quantite;
    }

    /**
     * @return
     */
    public String getDosage() {
        // TODO implement here
        return dosage;
    }

    

    /**
     * @param codeMedicament 
     * @return
     */
    public void setCodeMedicament(String codeMedicament) {
        // TODO implement here
        this.codeMedicament=codeMedicament;
    }

    /**
     * @param codeOrdonnance 
     * @return
     */
    public void setCodeOrdonnance(String codeOrdonnance) {
        // TODO implement here
        this.codeOrdonnance=codeOrdonnance;
    }

    /**
     * @param nomMedicament 
     * @return
     */
    public void setNomMedicament(String nomMedicament) {
        // TODO implement here
        this.nomMedicament=nomMedicament;
    }

    /**
     * @param quantite 
     * @return
     */
    public void setQuantite(int quantite) {
        // TODO implement here
        this.quantite=quantite;
    }

    /**
     * @param dosage 
     * @return
     */
    public void setDosage(String dosage) {
        // TODO implement here
        this.dosage=dosage;
    }



	@Override
	public String toString() {
		return "MedicamentOrdonnance [codeMedicament=" + codeMedicament + ", codeOrdonnance=" + codeOrdonnance
				+ ", nomMedicament=" + nomMedicament + ", quantite=" + quantite + ", dosage=" + dosage + "]";
	}
    
    
    

}