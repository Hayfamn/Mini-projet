package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import metier.Medicament;

public class MedicamentDAO {
	
	private static final SingletonConnection PreparedStatement = null;

	public Medicament getMedicament(String codeMedicament) {
	    Medicament medicament = null;
	    Connection conn=SingletonConnection.getInstance();
    	try {
    	    PreparedStatement ps;
    		ps = conn.prepareStatement("select * from medicament where codeMedicament=?");
    		ps.setString(1, codeMedicament);
    	    ResultSet rs=ps.executeQuery();
	        if (rs.next()) {
	            String codeFamille = rs.getString("codeFamille");
	            String libelle = rs.getString("libelle");
	            int qte = rs.getInt("qte");
	            float prix = rs.getFloat("prix");
	            Date dateLivr = rs.getDate("dateLivr");
	            Date dateExp = rs.getDate("dateExp");
	            int stock = rs.getInt("stock");
	            medicament = new Medicament(codeMedicament, codeFamille, libelle, qte, prix, dateLivr, dateExp, stock);
	        }
	        conn.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return medicament;
	}

}
