package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import metier.Client;
import metier.Medicament;
import metier.Ordonnance;
public class PharmacienDAO implements java.lang.AutoCloseable{

    /**
     * @return
     */
    public List<Client> consulterClient() {
        // TODO implement here
    	List<Client> clients=new ArrayList<Client>();
    	Connection conn=SingletonConnection.getInstance();
    	try {
    	    PreparedStatement ps;
    		ps = conn.prepareStatement("select * from clientt");
    	    ResultSet rs=ps.executeQuery();
    	    while(rs.next())
    	    {
    	    	Client cli=new Client();
    	    	cli.setIdClient(rs.getInt("idClient"));
    	    	cli.setNomClient(rs.getString("nomClient"));
    	    	cli.setPrenomClient(rs.getString("prenomClient"));
    	    	cli.setCredit(rs.getFloat("credit"));
    	    	cli.setCodeOrdonnance(rs.getString("codeOrdonnance"));
    	        clients.add(cli);
    	    }
    	    ps.close();
    	} catch (SQLException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
    	return clients;
        
    }

    /**
     * @return
     */
    public List<Medicament> consulterMédicament() {
        // TODO implement here
    	List<Medicament> medicaments=new ArrayList<Medicament>();
    	Connection conn=SingletonConnection.getInstance();
    	try {
    	    PreparedStatement ps;
    		ps = conn.prepareStatement("select * from medicament");
    	    ResultSet rs=ps.executeQuery();
    	    while(rs.next())
    	    {
    	    	Medicament medic=new Medicament();
    	    	medic.setCodeMedicament(rs.getString("codeMedicament"));
    	    	medic.setCodeFamille(rs.getString("codeFamille"));
    	    	medic.setLibelleMedicament(rs.getString("libelleMedicament"));
    	    	medic.setQte(rs.getInt("qte"));
    	    	medic.setPrix(rs.getFloat("prix"));
    	    	medic.setDateLivr(rs.getDate("dateLivr"));
    	    	medic.setDateExp(rs.getDate("dateExp"));
    	    	medic.setStock(rs.getInt("stock"));
    	        medicaments.add(medic);
    	    }
    	    ps.close();
    	} catch (SQLException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
    	return medicaments;
        
    }
    
    
    
    /**
     * @return
     */
    public List<Ordonnance> consulterOrdonnance() {
        // TODO implement here
    	List<Ordonnance> ordonnances=new ArrayList<Ordonnance>();
    	Connection conn=SingletonConnection.getInstance();
    	try {
    	    PreparedStatement ps;
    		ps = conn.prepareStatement("select * from ordonnance");
    	    ResultSet rs=ps.executeQuery();
    	    while(rs.next())
    	    {
    	    	Ordonnance ordo=new Ordonnance();
    	    	ordo.setCodeOrdonnance(rs.getString("codeOrdonnance"));
    	    	ordo.setLibelleOrdonnance(rs.getString("libelleOrdonnance"));
    	    	ordo.setDateOrdonnance(rs.getDate("dateOrdonnance"));
    	        ordonnances.add(ordo);
    	    }
    	    ps.close();
    	} catch (SQLException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	}
    	return ordonnances;
        
    }
    

    /**
     * @param ord 
     * @return
     */
    public void ajoutOrdonnance(Ordonnance ord) {
        // TODO implement here
    	Connection conn=SingletonConnection.getInstance();
		try {
		    PreparedStatement ps;
			ps = conn.prepareStatement("insert into ordonnance(codeOrdonnance, libelleOrdonnance, dateOrdonnance) values(?, ?, ?)");
		    ps.setString(1,ord.getCodeOrdonnance());
		    ps.setString(2, ord.getLibelleOrdonnance());
		    ps.setDate(3, ord.getDateOrdonnance());
		    ps.executeUpdate();
		    ps.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getErrorCode());
			e.printStackTrace();
		}
        
    }

    /**
     * @param ord 
     * @return
     */
    public void modifOrdonnance(Ordonnance ord) {
        // TODO implement here
    	Connection conn=SingletonConnection.getInstance();
    	try {
    		PreparedStatement ps;
    		ps = conn.prepareStatement("update ordonnance set libelleOrdonnance=?, dateOrdonnance=? where codeOrdonnance=?");
    		ps.setString(1, ord.getLibelleOrdonnance());
    		ps.setDate(2, ord.getDateOrdonnance());
    		ps.setString(3, ord.getCodeOrdonnance());
    		ps.executeUpdate();
    		ps.close();
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
        
    }

    /**
     * @param codeOrd 
     * @return
     */
    public void supprimOrdonnance(String codeOrd) {
        // TODO implement here
    	Connection conn=SingletonConnection.getInstance();
    	try {
    		PreparedStatement ps;
    		ps=conn.prepareStatement("delete from ordonnance where codeOrdonnance=?");
    		ps.setString(1, codeOrd);
    		ps.executeUpdate();
    		ps.close();
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
        
    }

    /**
     * @param codeOrd 
     * @return
     */
    public List<Ordonnance> recherchOrdonnance(String codeOrd) {
        // TODO implement here
    	List<Ordonnance> ordonnances=new ArrayList<Ordonnance>();
    	Connection conn=SingletonConnection.getInstance();
    	try {
    		PreparedStatement ps;
    		ps=conn.prepareStatement("select * from ordonnance where codeOrdonnance=?");
    		ps.setString(1, codeOrd);
    		ResultSet rs=ps.executeQuery();
    		if(rs.next()) {
    			Ordonnance ordo=new Ordonnance();
    			ordo.setCodeOrdonnance(codeOrd);
    			ordo.setLibelleOrdonnance(rs.getString("libelleOrdonnance"));
    			ordo.setDateOrdonnance(rs.getDate("dateOrdonnance"));
    			ordonnances.add(ordo);
    		}
    		ps.close();
    		
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
    	return ordonnances;
    }
    
    
    public List<Medicament> recherchMedicament(String codeMedic) {
        // TODO implement here
    	List<Medicament> medicaments=new ArrayList<Medicament>();
    	Connection conn=SingletonConnection.getInstance();
    	try {
    		PreparedStatement ps;
    		ps=conn.prepareStatement("select * from Medicament where codeMedicament=?");
    		ps.setString(1, codeMedic);
    		ResultSet rs=ps.executeQuery();
    		if(rs.next()) {
    			Medicament medic=new Medicament();
    			medic.setCodeMedicament(codeMedic);
    			medic.setCodeFamille(rs.getString("codeFamille"));
    			medic.setLibelleMedicament(rs.getString("libelleMedicament"));
    			medic.setQte(rs.getInt("qte"));
    			medic.setPrix(rs.getFloat("prix"));
    			medic.setDateLivr(rs.getDate("dateLivr"));
    			medic.setDateExp(rs.getDate("dateExp"));
    			medic.setStock(rs.getInt("stock"));
    			medicaments.add(medic);
    		}
    		ps.close();
    		
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
    	return medicaments;
    }
    
    
    
    
    public Medicament rechercherMedicament(String codeMedic) {
        // TODO implement here
    	Medicament medic=new Medicament();
    	Connection conn=SingletonConnection.getInstance();
    	try {
    		PreparedStatement ps;
    		ps=conn.prepareStatement("select * from Medicament where codeMedicament=?");
    		ps.setString(1, codeMedic);
    		ResultSet rs=ps.executeQuery();
    		if(rs.next()) {
    			
    			medic.setCodeMedicament(codeMedic);
    			medic.setCodeFamille(rs.getString("codeFamille"));
    			medic.setLibelleMedicament(rs.getString("libelleMedicament"));
    			medic.setQte(rs.getInt("qte"));
    			medic.setPrix(rs.getFloat("prix"));
    			medic.setDateLivr(rs.getDate("dateLivr"));
    			medic.setDateExp(rs.getDate("dateExp"));
    			medic.setStock(rs.getInt("stock"));
    			
    		}
    		ps.close();
    		
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
    	return medic;
    }
    
    
    

	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	
	
	

}
