package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import metier.Client;
import metier.Medicament;
public class AdministrateurDAO {

    /**
     * @param client 
     * @return
     */
    public void ajoutClient(Client client) {
        // TODO implement here
    	Connection conn= SingletonConnection.getInstance();
    	try {
    		PreparedStatement ps;
    		ps=conn.prepareStatement("insert into clientt(idClient, nomClient, prenomClient, credit, codeOrdonnance) values(?, ?, ?, ?, ?)");
    		ps.setInt(1, client.getIdClient());
    		ps.setString(2, client.getNomClient());
    		ps.setString(3, client.getPrenomClient());
    		ps.setFloat(4, client.getCredit());
    		ps.setString(5, client.getCodeOrdonnance());
    		ps.executeUpdate();
    		ps.close();
    		
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
        
    }

    /**
     * @param client 
     * @return
     */
    public void modifClient(Client client) {
        // TODO implement here
    	Connection conn=SingletonConnection.getInstance();
    	try {
    	    PreparedStatement ps;
    	    ps=conn.prepareStatement("update clientt set nomClient=?, prenomClient=?, credit=?, codeOrdonnance=? where idClient=?");
    	    ps.setString(1,client.getNomClient());
    	    ps.setString(2, client.getPrenomClient());
    	    ps.setFloat(3, client.getCredit());
    	    ps.setString(4, client.getCodeOrdonnance());
    	    ps.setInt(5, client.getIdClient());
    	    ps.executeUpdate();
    	    ps.close();
    	
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
    	
    }

    /**
     * @param client 
     * @return
     */
    public void supprimClient(int idClient) {
        // TODO implement here
    	Connection conn=SingletonConnection.getInstance();
    	try {
    		PreparedStatement ps;
    		ps=conn.prepareStatement("delete from clientt where idClient=?");
    		ps.setInt(1,idClient);
    		ps.executeUpdate();
    		ps.close();
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
    	
    }

    /**
     * @param medicament 
     * @return
     */
    public void ajoutMedicament(Medicament medicament) {
        // TODO implement here
    	Connection conn=SingletonConnection.getInstance();
    	try {
    		PreparedStatement ps;
    		ps=conn.prepareStatement("insert into medicament(codeMedicament, codeFamille, libelleMedicament, qte, prix, dateLivr, dateExp, stock) values(?, ?, ?, ?, ?, ?, ?, ?)");
    		ps.setString(1, medicament.getCodeMedicament());
    		ps.setString(2, medicament.getCodeFamille());
    		ps.setString(3, medicament.getLibelleMedicament());
    		ps.setInt(4, medicament.getQte());
    		ps.setFloat(5, medicament.getPrix());
    		ps.setDate(6, medicament.getDateLivr());
    		ps.setDate(7, medicament.getDateExp());
    		ps.setInt(8, medicament.getStock());
    		ps.executeUpdate();
    		ps.close();
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
        
    }

    /**
     * @param medicament 
     * @return
     */
    public void modifMedicament(Medicament medicament) {
        // TODO implement here
    	Connection conn=SingletonConnection.getInstance();
    	try {
    		PreparedStatement ps;
    		ps=conn.prepareStatement("update medicament set codeFamille=?, libelleMedicament=?, qte=?, prix=?, dateLivr=?, dateExp=?, stock=? where codeMedicament=?");
    		ps.setString(1, medicament.getCodeFamille());
    		ps.setString(2, medicament.getLibelleMedicament());
    		ps.setInt(3, medicament.getQte());
    		ps.setFloat(4, medicament.getPrix());
    		ps.setDate(5, medicament.getDateLivr());
    		ps.setDate(6, medicament.getDateExp());
    		ps.setInt(7, medicament.getStock());
    		ps.setString(8, medicament.getCodeMedicament());
    		ps.executeUpdate();
    		ps.close();
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
        
    }

    /**
     * @param codeMedi 
     * @return
     */
    public void supprimMedicament(String codeMedi) {
        // TODO implement here
    	Connection conn=SingletonConnection.getInstance();
    	try {
    		PreparedStatement ps;
    		ps=conn.prepareStatement("delete from medicament where codeMedicament=?");
    		ps.setString(1,codeMedi);
    		ps.executeUpdate();
    		ps.close();
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
        
    }
    
    
    public static void Enregistrer() {
    	Connection conn=SingletonConnection.getInstance();
    	try {
    		conn.setAutoCommit(false);
    		conn.commit();
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
    }
    

    /**
     * @param codeMedi 
     * @return
     */
    public void consultQteTotalStk(String codeMedi) {
        // TODO implement here
    	Connection conn=SingletonConnection.getInstance();
    	try {
    		PreparedStatement ps;
    		ps=conn.prepareStatement("select stock from medicament where codeMedicament=?");
    		ps.setString(1, codeMedi);
    		ps.executeQuery();
    		ps.close();
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
        
    }

    /**
     * @param medicament 
     * @return
     */
    public void ajoutStk(Medicament medicament,int stock) {
        // TODO implement here
    	Connection conn=SingletonConnection.getInstance();
    	try {
    		PreparedStatement ps;
    		ps=conn.prepareStatement("update medicament set stock=? where codeMedicament=?");
    		ps.setInt(1, medicament.getStock()+stock);
    		ps.setString(2, medicament.getCodeMedicament());
    		ps.executeUpdate();
    		ps.close();
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
        
    }

    /**
     * @param medicament 
     * @return
     */
    public void supprimStk(Medicament medicament, int stock) {
        // TODO implement here
    	Connection conn=SingletonConnection.getInstance();
    	try {
    		PreparedStatement ps;
    		ps=conn.prepareStatement("update medicament set stock=? where codeMedicament=?");
    		ps.setInt(1, medicament.getStock()-stock);
    		ps.setString(2, medicament.getCodeMedicament());
    		ps.executeUpdate();
    		ps.close();
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}
        
    }

}
