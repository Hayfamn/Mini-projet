package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import metier.MedicamentOrdonnance;

public class MedicamentOrdonnanceDAO {
	
	public List<MedicamentOrdonnance> getMedicamentByOrdonnance(String codeOrd) {
	    List<MedicamentOrdonnance> medicament = new ArrayList<MedicamentOrdonnance>();

		Connection conn = SingletonConnection.getInstance();
		try {
			PreparedStatement ps;
			ps = conn.prepareStatement("select codeMedicament, nomMedicament, quantite, dosage from medicamentordonnance where codeOrdonnance=?;");
    		ps.setString(1, codeOrd);
    	    ResultSet rs=ps.executeQuery();
	        while (rs.next()) {
	            String codeMedicament = rs.getString("codeMedicament");
	            String nomMedicament = rs.getString("nomMedicament");
	            int qte = rs.getInt("quantite");
	            String dosage = rs.getString("dosage"); 
	            medicament.add(new MedicamentOrdonnance(codeOrd,codeMedicament, nomMedicament, qte, dosage));

	        }
	        conn.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return medicament;
		}
		
	

}


